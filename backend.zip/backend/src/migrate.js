require('dotenv').config();
const { Pool } = require('pg');
const fs = require('fs');
const path = require('path');

const pool = new Pool({ connectionString: process.env.DATABASE_URL });

async function migrate() {
  const migrationsDir = path.join(__dirname, '../migrations');
  const files = fs.readdirSync(migrationsDir).sort();
  
  console.log('Running migrations...');
  
  for (const file of files) {
    if (!file.endsWith('.sql')) continue;
    console.log(`  Running: ${file}`);
    const sql = fs.readFileSync(path.join(migrationsDir, file), 'utf8');
    try {
      await pool.query(sql);
      console.log(`  ✓ ${file}`);
    } catch (e) {
      console.error(`  ✗ ${file}: ${e.message}`);
      // Continue on seed errors (duplicates)
      if (!file.includes('seed')) throw e;
    }
  }
  
  console.log('Migrations complete!');
  await pool.end();
}

migrate().catch(console.error);
