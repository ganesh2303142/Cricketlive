require('dotenv').config();
const express = require('express');
const http = require('http');
const WebSocket = require('ws');
const cors = require('cors');
const { Pool } = require('pg');

const app = express();
const server = http.createServer(app);
const wss = new WebSocket.Server({ server, path: '/ws' });

// ── Database ───────────────────────────────────────────────
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: false } : false
});

global.db = pool;
global.wss = wss;

// Test DB connection on startup
pool.query('SELECT 1').then(() => {
  console.log('✅ Database connected');
}).catch(e => {
  console.error('❌ Database connection failed:', e.message);
  console.error('   Check DATABASE_URL in your .env file');
});

// ── Middleware ─────────────────────────────────────────────
app.use(cors({
  origin: process.env.FRONTEND_URL || 'http://localhost:3000',
  credentials: true
}));
app.use(express.json({ limit: '2mb' }));
app.use(express.urlencoded({ extended: true }));

app.use((req, res, next) => {
  console.log(`${new Date().toISOString().slice(11, 19)} ${req.method} ${req.path}`);
  next();
});

// ── WebSocket ──────────────────────────────────────────────
wss.on('connection', (ws) => {
  ws.isAlive = true;
  ws.on('pong', () => { ws.isAlive = true; });
  ws.on('message', (message) => {
    try {
      const data = JSON.parse(message);
      if (data.type === 'subscribe' && data.matchId) {
        ws.subscribedMatch = data.matchId;
        ws.send(JSON.stringify({ type: 'subscribed', matchId: data.matchId }));
      }
    } catch (e) {}
  });
  ws.on('close', () => {});
});

// Heartbeat to detect dead connections
setInterval(() => {
  wss.clients.forEach(ws => {
    if (!ws.isAlive) return ws.terminate();
    ws.isAlive = false;
    ws.ping();
  });
}, 30000);

// Broadcast to match subscribers
global.broadcastMatch = (matchId, data) => {
  const msg = JSON.stringify(data);
  wss.clients.forEach(client => {
    if (client.readyState === WebSocket.OPEN) {
      if (!client.subscribedMatch || client.subscribedMatch === matchId || data.type === 'match_list_update') {
        client.send(msg);
      }
    }
  });
};

// ── Routes ─────────────────────────────────────────────────
app.use('/api/auth',    require('./routes/auth'));
app.use('/api/matches', require('./routes/matches'));
app.use('/api/teams',   require('./routes/teams'));
app.use('/api/players', require('./routes/players'));
app.use('/api/series',  require('./routes/series'));
app.use('/api/scoring', require('./routes/scoring'));
app.use('/api/admin',   require('./routes/admin'));

// ── Health check ───────────────────────────────────────────
app.get('/health', async (req, res) => {
  try {
    await pool.query('SELECT 1');
    res.json({
      status: 'ok',
      db: 'connected',
      timestamp: new Date().toISOString(),
      env: {
        email_configured: !!(process.env.EMAIL_USER && process.env.EMAIL_USER !== 'your_gmail@gmail.com'),
        sms_configured: !!(process.env.TWILIO_ACCOUNT_SID && process.env.TWILIO_ACCOUNT_SID !== 'your_twilio_account_sid'),
        node_env: process.env.NODE_ENV
      }
    });
  } catch (e) {
    res.status(500).json({ status: 'error', db: 'disconnected', message: e.message });
  }
});

// ── 404 & Error handler ────────────────────────────────────
app.use((req, res) => res.status(404).json({ error: 'Route not found' }));
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ error: err.message || 'Internal server error' });
});

// ── Start ──────────────────────────────────────────────────
const PORT = process.env.PORT || 4000;
server.listen(PORT, () => {
  console.log(`\n🏏 Cricket Live Server running on port ${PORT}`);
  console.log(`📡 WebSocket: ws://localhost:${PORT}/ws`);
  console.log(`🔍 Health:    http://localhost:${PORT}/health`);
  if (process.env.EMAIL_USER === 'your_gmail@gmail.com' || !process.env.EMAIL_USER) {
    console.log(`\n⚠️  EMAIL not configured — OTP will print to console (dev mode)`);
    console.log(`   Set EMAIL_USER and EMAIL_PASS in .env for production`);
  }
  if (process.env.TWILIO_ACCOUNT_SID === 'your_twilio_account_sid' || !process.env.TWILIO_ACCOUNT_SID) {
    console.log(`⚠️  SMS (Twilio) not configured — OTP will print to console (dev mode)\n`);
  }
});
