// src/services/otpService.js
// Real OTP delivery via Nodemailer (email) and Twilio (SMS)

const nodemailer = require('nodemailer');
const bcrypt = require('bcryptjs');
const crypto = require('crypto');

// ============================================================
// EMAIL TRANSPORT (Nodemailer)
// ============================================================
let emailTransporter = null;

function getEmailTransporter() {
  if (emailTransporter) return emailTransporter;

  const { EMAIL_HOST, EMAIL_PORT, EMAIL_SECURE, EMAIL_USER, EMAIL_PASS } = process.env;

  if (!EMAIL_USER || !EMAIL_PASS || EMAIL_USER === 'your_gmail@gmail.com') {
    console.warn('⚠️  EMAIL not configured. Set EMAIL_USER and EMAIL_PASS in .env');
    return null;
  }

  emailTransporter = nodemailer.createTransport({
    host: EMAIL_HOST || 'smtp.gmail.com',
    port: parseInt(EMAIL_PORT || '587'),
    secure: EMAIL_SECURE === 'true',
    auth: { user: EMAIL_USER, pass: EMAIL_PASS },
    tls: { rejectUnauthorized: false }
  });

  return emailTransporter;
}

// ============================================================
// SMS via Twilio
// ============================================================
function getTwilioClient() {
  const { TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN } = process.env;

  if (!TWILIO_ACCOUNT_SID || !TWILIO_AUTH_TOKEN ||
      TWILIO_ACCOUNT_SID === 'your_twilio_account_sid') {
    console.warn('⚠️  TWILIO not configured. Set TWILIO_ACCOUNT_SID and TWILIO_AUTH_TOKEN in .env');
    return null;
  }

  try {
    const twilio = require('twilio');
    return twilio(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN);
  } catch (e) {
    console.warn('Twilio not installed. Run: npm install twilio');
    return null;
  }
}

// ============================================================
// GENERATE OTP
// ============================================================
function generateOTP() {
  return crypto.randomInt(100000, 999999).toString();
}

// ============================================================
// SEND EMAIL OTP
// ============================================================
async function sendEmailOTP(email, otp) {
  const transporter = getEmailTransporter();

  if (!transporter) {
    // DEV MODE: log to console if email not configured
    if (process.env.NODE_ENV !== 'production') {
      console.log(`\n🔑 DEV OTP for ${email}: ${otp}\n`);
      return { success: true, dev_mode: true };
    }
    throw new Error('Email service not configured. Please set EMAIL_USER and EMAIL_PASS in .env');
  }

  const expiryMinutes = parseInt(process.env.OTP_EXPIRY_MINUTES || '10');

  const mailOptions = {
    from: process.env.EMAIL_FROM || `"CricketLive" <${process.env.EMAIL_USER}>`,
    to: email,
    subject: 'CricketLive - Password Reset OTP',
    html: `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <style>
          body { font-family: Arial, sans-serif; background: #f4f4f4; margin: 0; padding: 20px; }
          .container { max-width: 480px; margin: 0 auto; background: white; border-radius: 12px; padding: 32px; }
          .header { text-align: center; margin-bottom: 24px; }
          .logo { font-size: 32px; margin-bottom: 8px; }
          .title { font-size: 22px; font-weight: bold; color: #111; }
          .accent { color: #22c55e; }
          .otp-box { background: #f0fdf4; border: 2px solid #22c55e; border-radius: 12px; padding: 24px; text-align: center; margin: 24px 0; }
          .otp { font-size: 40px; font-weight: bold; letter-spacing: 12px; color: #111; font-family: monospace; }
          .expiry { color: #666; font-size: 14px; margin-top: 8px; }
          .warning { background: #fef3c7; border-left: 4px solid #f59e0b; padding: 12px 16px; border-radius: 4px; font-size: 13px; color: #78350f; margin: 16px 0; }
          .footer { text-align: center; font-size: 12px; color: #999; margin-top: 24px; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <div class="logo">🏏</div>
            <div class="title">Cricket<span class="accent">Live</span></div>
          </div>
          <p style="color:#444; font-size:15px;">You requested a password reset. Use the OTP below:</p>
          <div class="otp-box">
            <div class="otp">${otp}</div>
            <div class="expiry">Expires in ${expiryMinutes} minutes</div>
          </div>
          <div class="warning">
            ⚠️ Never share this OTP with anyone. CricketLive staff will never ask for it.
          </div>
          <p style="color:#444; font-size:14px;">If you did not request this, please ignore this email. Your account is safe.</p>
          <div class="footer">CricketLive Admin Portal · This is an automated message</div>
        </div>
      </body>
      </html>
    `
  };

  await transporter.sendMail(mailOptions);
  return { success: true };
}

// ============================================================
// SEND SMS OTP
// ============================================================
async function sendSmsOTP(phone, otp) {
  const client = getTwilioClient();

  if (!client) {
    // DEV MODE
    if (process.env.NODE_ENV !== 'production') {
      console.log(`\n🔑 DEV OTP for ${phone}: ${otp}\n`);
      return { success: true, dev_mode: true };
    }
    throw new Error('SMS service not configured. Please set TWILIO_ACCOUNT_SID and TWILIO_AUTH_TOKEN in .env');
  }

  const expiryMinutes = parseInt(process.env.OTP_EXPIRY_MINUTES || '10');
  const fromNumber = process.env.TWILIO_PHONE_NUMBER;

  await client.messages.create({
    body: `Your CricketLive password reset OTP is: ${otp}. Valid for ${expiryMinutes} minutes. Do not share.`,
    from: fromNumber,
    to: phone
  });

  return { success: true };
}

// ============================================================
// STORE OTP IN DB
// ============================================================
async function storeOTP(identifier, identifierType, otp, ipAddress) {
  const expiryMinutes = parseInt(process.env.OTP_EXPIRY_MINUTES || '10');
  const expiresAt = new Date(Date.now() + expiryMinutes * 60 * 1000);

  // Hash the OTP before storing
  const otpHash = await bcrypt.hash(otp, 10);

  // Invalidate previous unused OTPs for this identifier
  await global.db.query(
    `UPDATE otp_verifications SET used_at = NOW() WHERE identifier = $1 AND used_at IS NULL AND expires_at > NOW()`,
    [identifier]
  );

  // Store new OTP
  const result = await global.db.query(
    `INSERT INTO otp_verifications (identifier, identifier_type, otp_hash, purpose, expires_at, ip_address)
     VALUES ($1, $2, $3, 'password_reset', $4, $5) RETURNING id`,
    [identifier, identifierType, otpHash, expiresAt, ipAddress]
  );

  return result.rows[0].id;
}

// ============================================================
// VERIFY OTP
// ============================================================
async function verifyOTP(identifier, otp) {
  const maxAttempts = parseInt(process.env.OTP_MAX_ATTEMPTS || '5');

  // Find valid OTP
  const result = await global.db.query(
    `SELECT * FROM otp_verifications
     WHERE identifier = $1
       AND used_at IS NULL
       AND expires_at > NOW()
       AND purpose = 'password_reset'
     ORDER BY created_at DESC LIMIT 1`,
    [identifier]
  );

  const record = result.rows[0];
  if (!record) {
    return { valid: false, reason: 'OTP expired or not found. Please request a new one.' };
  }

  if (record.attempts >= maxAttempts) {
    return { valid: false, reason: 'Too many incorrect attempts. Please request a new OTP.' };
  }

  // Increment attempts
  await global.db.query(
    `UPDATE otp_verifications SET attempts = attempts + 1 WHERE id = $1`,
    [record.id]
  );

  // Verify hash
  const match = await bcrypt.compare(otp, record.otp_hash);
  if (!match) {
    const remaining = maxAttempts - (record.attempts + 1);
    return { valid: false, reason: `Incorrect OTP. ${remaining} attempts remaining.` };
  }

  // Mark as used
  await global.db.query(
    `UPDATE otp_verifications SET used_at = NOW() WHERE id = $1`,
    [record.id]
  );

  return { valid: true, otpId: record.id };
}

// ============================================================
// RATE LIMITING CHECK
// ============================================================
async function checkRateLimit(identifier) {
  const windowMinutes = parseInt(process.env.OTP_RATE_LIMIT_WINDOW_MINUTES || '15');
  const maxRequests = parseInt(process.env.OTP_RATE_LIMIT_MAX_REQUESTS || '3');
  const windowStart = new Date(Date.now() - windowMinutes * 60 * 1000);

  const result = await global.db.query(
    `SELECT COUNT(*) as count FROM otp_verifications
     WHERE identifier = $1 AND created_at > $2`,
    [identifier, windowStart]
  );

  const count = parseInt(result.rows[0].count);
  if (count >= maxRequests) {
    return {
      allowed: false,
      message: `Too many OTP requests. Please wait ${windowMinutes} minutes before trying again.`
    };
  }

  return { allowed: true };
}

module.exports = {
  generateOTP,
  sendEmailOTP,
  sendSmsOTP,
  storeOTP,
  verifyOTP,
  checkRateLimit
};
