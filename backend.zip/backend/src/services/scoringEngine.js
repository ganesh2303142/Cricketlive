// Cricket Scoring Engine — Core Logic + Realistic Commentary Generator

class CricketScoringEngine {

  // ── Delivery validation ──────────────────────────────────
  validateDelivery(delivery) {
    const errors = [];
    if (!delivery.striker_id)    errors.push('Striker required');
    if (!delivery.bowler_id)     errors.push('Bowler required');
    if (delivery.runs_off_bat < 0 || delivery.runs_off_bat > 6)
      errors.push('Invalid runs off bat (0-6)');
    if (delivery.is_wicket) {
      if (!delivery.wicket_type)         errors.push('Wicket type required');
      if (!delivery.dismissed_player_id) errors.push('Dismissed player required');
      if (delivery.extra_type === 'no_ball') {
        if (['bowled','lbw','caught','hit_wicket'].includes(delivery.wicket_type))
          errors.push(`Cannot be dismissed ${delivery.wicket_type} off a no-ball`);
      }
      if (delivery.wicket_type === 'caught' && !delivery.fielder_id)
        errors.push('Fielder required for caught dismissal');
      if (delivery.wicket_type === 'stumped' && delivery.extra_type === 'no_ball')
        errors.push('Cannot be stumped off a no-ball');
    }
    return errors;
  }

  // ── Delivery totals ──────────────────────────────────────
  calculateDeliveryTotals(delivery) {
    const { runs_off_bat = 0, extra_type, wide_runs = 0, bye_runs = 0, leg_bye_runs = 0 } = delivery;
    let extras_total = 0, total_runs = 0, is_legal_ball = true;
    switch (extra_type) {
      case 'wide':
        extras_total = wide_runs > 0 ? wide_runs : 1;
        total_runs   = extras_total;
        is_legal_ball = false; break;
      case 'no_ball':
        extras_total = 1 + bye_runs + leg_bye_runs;
        total_runs   = runs_off_bat + extras_total;
        is_legal_ball = false; break;
      case 'bye':
        extras_total = bye_runs; total_runs = bye_runs; break;
      case 'leg_bye':
        extras_total = leg_bye_runs; total_runs = leg_bye_runs; break;
      default:
        extras_total = 0; total_runs = runs_off_bat;
    }
    return { extras_total, total_runs, is_legal_ball };
  }

  // ── Strike rotation ──────────────────────────────────────
  shouldRotateStrike(delivery, isEndOfOver) {
    const { runs_off_bat = 0, extra_type, is_wicket, wicket_type, bye_runs = 0, leg_bye_runs = 0 } = delivery;
    if (isEndOfOver) return true;
    if (extra_type === 'wide') return false;
    if (is_wicket && wicket_type === 'run_out') return false;
    if (['bye','leg_bye'].includes(extra_type)) return (bye_runs + leg_bye_runs) % 2 === 1;
    return runs_off_bat % 2 === 1;
  }

  calculateCRR(totalRuns, totalBalls) {
    if (!totalBalls) return 0;
    return parseFloat((totalRuns / totalBalls * 6).toFixed(2));
  }
  calculateRRR(target, currentRuns, ballsRemaining) {
    if (ballsRemaining <= 0) return 0;
    const need = target - currentRuns;
    if (need <= 0) return 0;
    return parseFloat((need / ballsRemaining * 6).toFixed(2));
  }
  formatOvers(legalBalls) {
    return parseFloat(`${Math.floor(legalBalls / 6)}.${legalBalls % 6}`);
  }
  shouldEndInnings(innings, matchOvers) {
    if (innings.total_wickets >= 10) return { end: true, reason: 'all_out' };
    if (Math.floor((innings.total_balls || 0) / 6) >= matchOvers) return { end: true, reason: 'overs_complete' };
    if (innings.target && innings.total_runs >= innings.target) return { end: true, reason: 'target_chased' };
    if (innings.declared) return { end: true, reason: 'declared' };
    return { end: false };
  }
  checkMaiden(overDeliveries) {
    const legalCount = overDeliveries.filter(d => d.is_legal_ball).length;
    const totalRuns  = overDeliveries.reduce((s, d) => s + (d.total_runs || 0), 0);
    return legalCount >= 6 && totalRuns === 0;
  }

  // ── Pick a template by rotating through options ──────────
  _pick(arr, seed) {
    return arr[Math.abs(seed || 0) % arr.length];
  }

  // ══════════════════════════════════════════════════════════
  // MAIN COMMENTARY GENERATOR
  // One entry per delivery, concise, varied, realistic.
  // ══════════════════════════════════════════════════════════
  generateCommentary(p) {
    const {
      display_ball, over_number = 0,
      runs_off_bat = 0, extra_type, is_wicket, wicket_type,
      wide_runs = 0, bye_runs = 0, leg_bye_runs = 0,
      striker_name, bowler_name, fielder_name,
      team_score_after, team_wickets_after,
      striker_runs_after, striker_balls_after,
    } = p;

    const ball    = display_ball || '?.?';
    const batter  = striker_name || 'Batter';
    const bowler  = bowler_name  || 'Bowler';
    const fielder = fielder_name || 'fielder';
    const seed    = Math.floor((team_score_after || 0) + (striker_runs_after || 0));
    const score   = (team_score_after !== undefined && team_wickets_after !== undefined)
      ? ` [${team_score_after}/${team_wickets_after}]` : '';
    const bs      = (striker_runs_after !== undefined && striker_balls_after !== undefined)
      ? ` — ${batter}: ${striker_runs_after}(${striker_balls_after})` : '';

    // ── WICKET ────────────────────────────────────────────
    if (is_wicket) {
      const wicketLines = {
        bowled: [
          `${ball}: ${bowler} to ${batter} — BOWLED! The stumps are rattled!`,
          `${ball}: ${bowler} to ${batter} — OUT! Clean bowled, back of a length delivery.`,
          `${ball}: ${bowler} to ${batter} — BOWLED! Through the gate!`,
        ],
        lbw: [
          `${ball}: ${bowler} to ${batter} — OUT! LBW, plumb in front, finger goes up.`,
          `${ball}: ${bowler} to ${batter} — OUT LBW! Full, swinging in, hits the pad.`,
          `${ball}: ${bowler} to ${batter} — Given! LBW, pitches in line, hits middle.`,
        ],
        caught: [
          `${ball}: ${bowler} to ${batter} — CAUGHT! c ${fielder} b ${bowler}. That's out!`,
          `${ball}: ${bowler} to ${batter} — OUT! Taken cleanly by ${fielder} at ${this._pick(['mid-off','cover','slip','mid-on','third man'],seed)}.`,
          `${ball}: ${bowler} to ${batter} — Edged and gone! ${fielder} takes it.`,
        ],
        run_out: [
          `${ball}: Run out! Direct hit — ${batter} is short of the crease!`,
          `${ball}: RUN OUT! Sharp fielding from ${fielder}, ${batter} is gone!`,
          `${ball}: Run out — ${batter} is well short, brilliant throw!`,
        ],
        stumped: [
          `${ball}: STUMPED! ${batter} goes for the drive, misses, ${fielder} does the rest!`,
          `${ball}: Out stumped! ${batter} advances down the track, well out of the crease.`,
          `${ball}: Stumped by ${fielder} off ${bowler}. Quick as a flash!`,
        ],
        hit_wicket: [
          `${ball}: ${bowler} to ${batter} — HIT WICKET! What a bizarre dismissal!`,
          `${ball}: Hit wicket — ${batter} clips the stumps while playing.`,
        ],
        retired_hurt:  [`${ball}: ${batter} retires hurt. Unfortunate.`],
        retired_out:   [`${ball}: ${batter} retires out.`],
        obstructing_field: [`${ball}: Out — obstructing the field. Very rare dismissal!`],
      };
      const lines = wicketLines[wicket_type] || [`${ball}: OUT! ${batter} is dismissed.`];
      return `${this._pick(lines, seed)}${score}`;
    }

    // ── SIX ───────────────────────────────────────────────
    if (runs_off_bat === 6) {
      const sixLines = [
        `${ball}: ${bowler} to ${batter} — SIX! Flat-batted over long-on, effortless!`,
        `${ball}: ${bowler} to ${batter} — MAXIMUM! Over mid-wicket, all along the ground — no, it's gone!`,
        `${ball}: ${bowler} to ${batter} — SIX! Steps back, gives himself room, launches it.`,
        `${ball}: ${bowler} to ${batter} — Gone downtown! ${batter} muscles one over the ropes.`,
        `${ball}: ${bowler} to ${batter} — HUGE! Back of a length, pulled over deep square, six!`,
      ];
      return `${this._pick(sixLines, seed)}${bs}${score}`;
    }

    // ── FOUR ──────────────────────────────────────────────
    if (runs_off_bat === 4) {
      const fourLines = [
        `${ball}: ${bowler} to ${batter} — FOUR! Driven through covers, bisects the field.`,
        `${ball}: ${bowler} to ${batter} — BOUNDARY! Clipped off the pads, races away fine.`,
        `${ball}: ${bowler} to ${batter} — Four! Inside edge, misses everything, beats the keeper.`,
        `${ball}: ${bowler} to ${batter} — Four! Pulled hard, over mid-wicket.`,
        `${ball}: ${bowler} to ${batter} — FOUR! Full toss, dispatched straight.`,
        `${ball}: ${bowler} to ${batter} — Four! Late cut, third man's got no chance.`,
      ];
      return `${this._pick(fourLines, seed)}${bs}${score}`;
    }

    // ── WIDE ──────────────────────────────────────────────
    if (extra_type === 'wide') {
      const wideRuns = wide_runs > 0 ? wide_runs : 1;
      const wideLines = wideRuns > 1
        ? [`${ball}: ${bowler} — Wide, and it races away for ${wideRuns - 1} more. ${wideRuns} extras.`]
        : [
          `${ball}: ${bowler} — Wide! Going down leg, umpire signals immediately.`,
          `${ball}: ${bowler} — Wide ball. Too far outside off stump.`,
          `${ball}: ${bowler} — That's a wide, straying down the leg side.`,
        ];
      return `${this._pick(wideLines, seed)}${score}`;
    }

    // ── NO BALL ───────────────────────────────────────────
    if (extra_type === 'no_ball') {
      const nbLines = runs_off_bat > 0
        ? [
          `${ball}: ${bowler} to ${batter} — No ball, and ${batter} dispatches it for ${runs_off_bat}! Free hit next.`,
          `${ball}: No ball + ${runs_off_bat} off the bat. Free hit incoming.`,
        ]
        : [
          `${ball}: ${bowler} — No ball! Front foot over the line. Free hit coming up.`,
          `${ball}: No ball from ${bowler}. Overstepped. Next ball is a free hit.`,
        ];
      return `${this._pick(nbLines, seed)}${score}`;
    }

    // ── BYE ───────────────────────────────────────────────
    if (extra_type === 'bye') {
      return `${ball}: ${bowler} to ${batter} — Bye! Past the keeper, they steal ${bye_runs} run${bye_runs !== 1 ? 's' : ''}.${score}`;
    }

    // ── LEG BYE ───────────────────────────────────────────
    if (extra_type === 'leg_bye') {
      const lbLines = [
        `${ball}: ${bowler} to ${batter} — Leg bye. Off the pad and away, ${leg_bye_runs} taken.`,
        `${ball}: ${bowler} to ${batter} — Clips the thigh pad, leg bye, ${leg_bye_runs} run${leg_bye_runs !== 1 ? 's' : ''}.`,
      ];
      return `${this._pick(lbLines, seed)}${score}`;
    }

    // ── DOT BALL ──────────────────────────────────────────
    if (runs_off_bat === 0) {
      const dotLines = [
        `${ball}: ${bowler} to ${batter} — Dot. Defended back down the pitch.`,
        `${ball}: ${bowler} to ${batter} — Good delivery, beaten outside off. Dot.`,
        `${ball}: ${bowler} to ${batter} — Tight line, pushed to mid-off. No run.`,
        `${ball}: ${bowler} to ${batter} — Dot ball. Played cautiously to cover.`,
        `${ball}: ${bowler} to ${batter} — Yorker, jammed out at the last moment.`,
        `${ball}: ${bowler} to ${batter} — Seaming away, outside edge misses slip. Dot.`,
        `${ball}: ${bowler} to ${batter} — Short ball, ducked. Dot.`,
      ];
      return `${this._pick(dotLines, seed)}${score}`;
    }

    // ── 1 RUN ────────────────────────────────────────────
    if (runs_off_bat === 1) {
      const oneLines = [
        `${ball}: ${bowler} to ${batter} — 1 run. Nudged to midwicket, single taken.`,
        `${ball}: ${bowler} to ${batter} — Pushed to mid-on, they scurry through for one.`,
        `${ball}: ${bowler} to ${batter} — 1. Tapped to cover-point, quick single.`,
        `${ball}: ${bowler} to ${batter} — Worked off hips, one run.`,
      ];
      return `${this._pick(oneLines, seed)}${bs}${score}`;
    }

    // ── 2 RUNS ───────────────────────────────────────────
    if (runs_off_bat === 2) {
      const twoLines = [
        `${ball}: ${bowler} to ${batter} — 2 runs. Driven to long-off, they run well.`,
        `${ball}: ${bowler} to ${batter} — Two! Punched to the gap, good running.`,
        `${ball}: ${bowler} to ${batter} — 2 runs, driven straight, the throw comes in too late.`,
      ];
      return `${this._pick(twoLines, seed)}${bs}${score}`;
    }

    // ── 3 RUNS ───────────────────────────────────────────
    if (runs_off_bat === 3) {
      const threeLines = [
        `${ball}: ${bowler} to ${batter} — 3 runs! Great running, they beat the throw.`,
        `${ball}: ${bowler} to ${batter} — Three! Hit to deep mid-wicket, excellent running.`,
      ];
      return `${this._pick(threeLines, seed)}${bs}${score}`;
    }

    // ── 5 RUNS ───────────────────────────────────────────
    if (runs_off_bat === 5) {
      return `${ball}: ${bowler} to ${batter} — Five runs! Overthrows add to the total.${score}`;
    }

    // Fallback
    return `${ball}: ${bowler} to ${batter} — ${runs_off_bat} run${runs_off_bat !== 1 ? 's' : ''}.${score}`;
  }

  // ── Over-complete commentary ─────────────────────────────
  generateOverCompleteCommentary(p) {
    const { over_number, bowler_name, over_runs, over_wickets, is_maiden, team_score, team_wickets } = p;
    const bowler = bowler_name || 'Bowler';
    const ov = over_number + 1;
    if (is_maiden)
      return `End of over ${ov}: MAIDEN! Outstanding bowling from ${bowler}. Score: ${team_score}/${team_wickets}`;
    if (over_wickets >= 2)
      return `End of over ${ov}: ${over_runs} runs, ${over_wickets} wickets — ${bowler} on a roll! [${team_score}/${team_wickets}]`;
    if (over_wickets === 1)
      return `End of over ${ov}: ${over_runs} runs, 1 wicket — ${bowler} strikes. [${team_score}/${team_wickets}]`;
    if (over_runs === 0)
      return `End of over ${ov}: Dot over from ${bowler}! Tight cricket. [${team_score}/${team_wickets}]`;
    if (over_runs >= 15)
      return `End of over ${ov}: BIG over! ${over_runs} runs plundered from ${bowler}. [${team_score}/${team_wickets}]`;
    return `End of over ${ov}: ${over_runs} run${over_runs !== 1 ? 's' : ''} from ${bowler}. [${team_score}/${team_wickets}]`;
  }

  // ── Milestone commentary ─────────────────────────────────
  generateMilestoneCommentary(p) {
    const { striker_name, runs, balls, milestone_type } = p;
    const batter = striker_name || 'Batter';
    if (milestone_type === 'fifty') {
      const fiftyLines = [
        `🏆 FIFTY! ${batter} brings up a superb half-century off ${balls} balls! Well played!`,
        `🏆 50 up for ${batter}! Reached in ${balls} deliveries — a fine innings.`,
        `🏆 Half-century! ${batter} raises the bat, 50 from ${balls} balls!`,
      ];
      return this._pick(fiftyLines, balls);
    }
    if (milestone_type === 'hundred') {
      const hundredLines = [
        `🏆 CENTURY! ${batter} completes a magnificent 100 off ${balls} balls! What a knock!`,
        `🏆 Three figures for ${batter}! 100 up, the crowd goes wild!`,
        `🏆 HUNDRED! ${batter} punches the air — ${balls} balls, a masterclass innings!`,
      ];
      return this._pick(hundredLines, balls);
    }
    return `Milestone: ${batter} reaches ${runs} runs!`;
  }

  // ── Innings-end commentary ────────────────────────────────
  generateInningsEndCommentary(p) {
    const { reason, total_runs, total_wickets, total_overs, batting_team_name, target } = p;
    const team = batting_team_name || 'Team';
    switch (reason) {
      case 'all_out':
        return `ALL OUT! ${team} bowled out for ${total_runs} in ${total_overs} overs.${target ? ` Target was ${target}.` : ''}`;
      case 'overs_complete':
        return `Innings over! ${team} finish on ${total_runs}/${total_wickets} in ${total_overs} overs.${target ? ` Target: ${total_runs + 1}.` : ''}`;
      case 'target_chased':
        return `TARGET REACHED! ${team} win with ${10 - total_wickets} wickets to spare! Final: ${total_runs}/${total_wickets} in ${total_overs} overs.`;
      case 'declared':
        return `${team} declare at ${total_runs}/${total_wickets} in ${total_overs} overs!`;
      default:
        return `Innings ended. ${team}: ${total_runs}/${total_wickets} in ${total_overs} overs.`;
    }
  }

  // ── Milestone check ───────────────────────────────────────
  _milestone(runsAfter, runsScored, extraType, strikerName) {
    if (!runsAfter || extraType) return null;
    const before = runsAfter - runsScored;
    if (before < 50 && runsAfter >= 50) return 'fifty';
    if (before < 100 && runsAfter >= 100) return 'hundred';
    return null;
  }

  // ── Commentary type classifier ────────────────────────────
  classifyCommentaryType(p) {
    const { is_wicket, runs_off_bat, extra_type } = p;
    if (is_wicket)          return 'wicket';
    if (runs_off_bat === 6) return 'six';
    if (runs_off_bat === 4) return 'boundary';
    return 'regular';
  }
}

module.exports = new CricketScoringEngine();
