const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { JWT_SECRET, authenticate } = require('../middleware/auth');
const otpService = require('../services/otpService');

const getIP = (req) => req.headers['x-forwarded-for']?.split(',')[0] || req.socket.remoteAddress || 'unknown';

async function auditLog(userId, eventType, identifier, ipAddress, success, metadata = {}) {
  try {
    await global.db.query(
      `INSERT INTO security_audit_log (user_id, event_type, identifier, ip_address, success, metadata)
       VALUES ($1, $2, $3, $4, $5, $6)`,
      [userId || null, eventType, identifier || null, ipAddress, success, JSON.stringify(metadata)]
    );
  } catch (e) { /* non-critical */ }
}

// POST /api/auth/login
router.post('/login', async (req, res) => {
  const { email, password } = req.body;
  const ip = getIP(req);
  if (!email || !password) return res.status(400).json({ error: 'Email and password required' });
  try {
    const result = await global.db.query(
      'SELECT * FROM users WHERE email = $1 AND is_active = true AND deleted_at IS NULL',
      [email.toLowerCase().trim()]
    );
    const user = result.rows[0];
    if (!user) { await auditLog(null, 'login_fail', email, ip, false); return res.status(401).json({ error: 'Invalid email or password' }); }
    const valid = await bcrypt.compare(password, user.password_hash);
    if (!valid) { await auditLog(user.id, 'login_fail', email, ip, false); return res.status(401).json({ error: 'Invalid email or password' }); }
    const token = jwt.sign({ id: user.id, email: user.email, name: user.name, role: user.role }, JWT_SECRET, { expiresIn: '7d' });
    await auditLog(user.id, 'login_success', email, ip, true);
    res.json({ token, user: { id: user.id, email: user.email, name: user.name, role: user.role, phone: user.phone } });
  } catch (e) { console.error(e); res.status(500).json({ error: 'Server error' }); }
});

// POST /api/auth/register
router.post('/register', async (req, res) => {
  const { email, password, name } = req.body;
  if (!email || !password || !name) return res.status(400).json({ error: 'All fields required' });
  if (password.length < 8) return res.status(400).json({ error: 'Password must be at least 8 characters' });
  try {
    const exists = await global.db.query('SELECT id FROM users WHERE email = $1 AND deleted_at IS NULL', [email.toLowerCase().trim()]);
    if (exists.rows.length > 0) return res.status(409).json({ error: 'Email already registered' });
    const hash = await bcrypt.hash(password, 12);
    const result = await global.db.query(
      'INSERT INTO users (email, password_hash, name, role) VALUES ($1, $2, $3, $4) RETURNING id, email, name, role',
      [email.toLowerCase().trim(), hash, name.trim(), 'user']
    );
    const user = result.rows[0];
    const token = jwt.sign({ id: user.id, email: user.email, name: user.name, role: user.role }, JWT_SECRET, { expiresIn: '7d' });
    res.status(201).json({ token, user });
  } catch (e) { console.error(e); res.status(500).json({ error: 'Server error' }); }
});

// GET /api/auth/me
router.get('/me', authenticate, async (req, res) => {
  try {
    const result = await global.db.query('SELECT id, email, name, role, phone FROM users WHERE id = $1 AND deleted_at IS NULL', [req.user.id]);
    if (!result.rows[0]) return res.status(404).json({ error: 'User not found' });
    res.json(result.rows[0]);
  } catch (e) { res.status(500).json({ error: 'Server error' }); }
});

// POST /api/auth/forgot-password/send-otp
router.post('/forgot-password/send-otp', async (req, res) => {
  const { identifier } = req.body;
  const ip = getIP(req);
  if (!identifier || !identifier.trim()) return res.status(400).json({ error: 'Email or phone number required' });

  const cleaned = identifier.trim();
  const isEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cleaned.toLowerCase());
  const isPhone = /^[+\d][\d\s\-()]{7,}$/.test(cleaned);

  if (!isEmail && !isPhone) return res.status(400).json({ error: 'Enter a valid email or phone number' });

  const identifierType = isEmail ? 'email' : 'phone';
  const lookupValue = isEmail ? cleaned.toLowerCase() : cleaned;
  const lookupField = isEmail ? 'email' : 'phone';

  const genericMsg = {
    success: true,
    message: `If an account exists, an OTP has been sent to your ${identifierType}.`,
    identifier_type: identifierType,
    expiry_minutes: parseInt(process.env.OTP_EXPIRY_MINUTES || '10')
  };

  try {
    const rateCheck = await otpService.checkRateLimit(lookupValue);
    if (!rateCheck.allowed) return res.status(429).json({ error: rateCheck.message });

    const userResult = await global.db.query(
      `SELECT id FROM users WHERE ${lookupField} = $1 AND is_active = true AND deleted_at IS NULL`,
      [lookupValue]
    );

    if (!userResult.rows[0]) {
      await auditLog(null, 'otp_account_not_found', lookupValue, ip, false);
      return res.json(genericMsg); // Same response for security
    }

    const otp = otpService.generateOTP();
    await otpService.storeOTP(lookupValue, identifierType, otp, ip);

    let sendResult;
    try {
      sendResult = identifierType === 'email'
        ? await otpService.sendEmailOTP(lookupValue, otp)
        : await otpService.sendSmsOTP(lookupValue, otp);
    } catch (sendErr) {
      return res.status(500).json({ error: `Failed to send OTP: ${sendErr.message}` });
    }

    await auditLog(userResult.rows[0].id, 'otp_sent', lookupValue, ip, true);

    const resp = { ...genericMsg };
    if (sendResult.dev_mode && process.env.NODE_ENV !== 'production') {
      resp.dev_otp = otp;
      resp.dev_note = 'DEV MODE: Configure EMAIL/SMS in .env for production. OTP will not be shown in production.';
    }
    return res.json(resp);
  } catch (e) {
    console.error('Send OTP error:', e);
    res.status(500).json({ error: 'Failed to send OTP. Please try again.' });
  }
});

// POST /api/auth/forgot-password/verify-otp
router.post('/forgot-password/verify-otp', async (req, res) => {
  const { identifier, otp } = req.body;
  const ip = getIP(req);
  if (!identifier || !otp) return res.status(400).json({ error: 'Identifier and OTP required' });
  if (!/^\d{6}$/.test(otp)) return res.status(400).json({ error: 'OTP must be 6 digits' });

  const cleaned = identifier.trim();
  const isEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cleaned.toLowerCase());
  const lookupValue = isEmail ? cleaned.toLowerCase() : cleaned;

  try {
    const verifyResult = await otpService.verifyOTP(lookupValue, otp);
    if (!verifyResult.valid) {
      await auditLog(null, 'otp_verify_fail', lookupValue, ip, false, { reason: verifyResult.reason });
      return res.status(400).json({ error: verifyResult.reason });
    }

    const userResult = await global.db.query(
      `SELECT id FROM users WHERE (email = $1 OR phone = $1) AND is_active = true AND deleted_at IS NULL`,
      [lookupValue]
    );
    if (!userResult.rows[0]) return res.status(400).json({ error: 'Account not found' });

    const resetToken = jwt.sign(
      { userId: userResult.rows[0].id, purpose: 'password_reset' },
      JWT_SECRET,
      { expiresIn: '15m' }
    );

    await auditLog(userResult.rows[0].id, 'otp_verified', lookupValue, ip, true);
    res.json({ success: true, reset_token: resetToken, message: 'OTP verified. You can now reset your password.', expires_in: '15 minutes' });
  } catch (e) {
    console.error('Verify OTP error:', e);
    res.status(500).json({ error: 'Verification failed. Please try again.' });
  }
});

// POST /api/auth/forgot-password/reset
router.post('/forgot-password/reset', async (req, res) => {
  const { reset_token, new_password, confirm_password } = req.body;
  const ip = getIP(req);
  if (!reset_token || !new_password || !confirm_password) return res.status(400).json({ error: 'All fields required' });
  if (new_password !== confirm_password) return res.status(400).json({ error: 'Passwords do not match' });
  if (new_password.length < 8) return res.status(400).json({ error: 'Password must be at least 8 characters' });
  if (!/(?=.*[A-Za-z])(?=.*\d)/.test(new_password)) return res.status(400).json({ error: 'Password must contain letters and numbers' });

  try {
    let decoded;
    try { decoded = jwt.verify(reset_token, JWT_SECRET); }
    catch (e) { return res.status(400).json({ error: 'Reset link expired or invalid. Please request a new OTP.' }); }
    if (decoded.purpose !== 'password_reset') return res.status(400).json({ error: 'Invalid reset token' });

    const hash = await bcrypt.hash(new_password, 12);
    await global.db.query('UPDATE users SET password_hash = $1, updated_at = NOW() WHERE id = $2', [hash, decoded.userId]);
    await auditLog(decoded.userId, 'password_reset_success', null, ip, true);
    res.json({ success: true, message: 'Password reset successfully. You can now log in.' });
  } catch (e) {
    console.error('Reset password error:', e);
    res.status(500).json({ error: 'Failed to reset password. Please try again.' });
  }
});

// POST /api/auth/change-password (authenticated)
router.post('/change-password', authenticate, async (req, res) => {
  const { old_password, new_password, confirm_password } = req.body;
  const ip = getIP(req);
  if (!old_password || !new_password || !confirm_password) return res.status(400).json({ error: 'All fields required' });
  if (new_password !== confirm_password) return res.status(400).json({ error: 'New passwords do not match' });
  if (new_password.length < 8) return res.status(400).json({ error: 'Password must be at least 8 characters' });
  if (!/(?=.*[A-Za-z])(?=.*\d)/.test(new_password)) return res.status(400).json({ error: 'Password must contain letters and numbers' });
  if (old_password === new_password) return res.status(400).json({ error: 'New password must differ from current password' });

  try {
    const result = await global.db.query('SELECT * FROM users WHERE id = $1 AND deleted_at IS NULL', [req.user.id]);
    const user = result.rows[0];
    if (!user) return res.status(404).json({ error: 'User not found' });
    const valid = await bcrypt.compare(old_password, user.password_hash);
    if (!valid) { await auditLog(user.id, 'change_password_fail', user.email, ip, false); return res.status(400).json({ error: 'Current password is incorrect' }); }
    const hash = await bcrypt.hash(new_password, 12);
    await global.db.query('UPDATE users SET password_hash = $1, updated_at = NOW() WHERE id = $2', [hash, user.id]);
    await auditLog(user.id, 'change_password_success', user.email, ip, true);
    res.json({ success: true, message: 'Password changed successfully' });
  } catch (e) {
    console.error('Change password error:', e);
    res.status(500).json({ error: 'Failed to change password' });
  }
});

// PATCH /api/auth/profile
router.patch('/profile', authenticate, async (req, res) => {
  const { phone, name } = req.body;
  const updates = []; const values = []; let idx = 1;
  if (phone !== undefined) { updates.push(`phone = $${idx++}`); values.push(phone || null); }
  if (name !== undefined && name.trim()) { updates.push(`name = $${idx++}`); values.push(name.trim()); }
  if (!updates.length) return res.status(400).json({ error: 'Nothing to update' });
  values.push(req.user.id);
  try {
    const result = await global.db.query(
      `UPDATE users SET ${updates.join(', ')}, updated_at = NOW() WHERE id = $${idx} RETURNING id, email, name, role, phone`,
      values
    );
    res.json(result.rows[0]);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

module.exports = router;
