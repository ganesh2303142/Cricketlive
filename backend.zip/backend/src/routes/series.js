// series.js — full CRUD with description, season, status
const express = require('express');
const router = express.Router();
const { authenticate, requireAdmin } = require('../middleware/auth');

// GET /api/series — list all series
router.get('/', async (req, res) => {
  try {
    const result = await global.db.query(`
      SELECT s.*,
        COUNT(DISTINCT m.id) FILTER (WHERE m.deleted_at IS NULL) as match_count,
        COUNT(DISTINCT m.id) FILTER (WHERE m.status = 'live' AND m.deleted_at IS NULL) as live_count
      FROM series s
      LEFT JOIN matches m ON m.series_id = s.id
      GROUP BY s.id
      ORDER BY s.created_at DESC
    `);
    res.json(result.rows);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// GET /api/series/:id — single series with matches
router.get('/:id', async (req, res) => {
  try {
    const sRes = await global.db.query('SELECT * FROM series WHERE id=$1', [req.params.id]);
    if (!sRes.rows[0]) return res.status(404).json({ error: 'Series not found' });
    const mRes = await global.db.query(`
      SELECT m.*,
        ta.name as team_a_name, ta.short_name as team_a_short, ta.color_primary as team_a_color,
        tb.name as team_b_name, tb.short_name as team_b_short, tb.color_primary as team_b_color,
        COALESCE(v.name, m.venue_name) as venue_name
      FROM matches m
      JOIN teams ta ON m.team_a_id = ta.id
      JOIN teams tb ON m.team_b_id = tb.id
      LEFT JOIN venues v ON m.venue_id = v.id
      WHERE m.series_id = $1 AND m.deleted_at IS NULL
      ORDER BY m.scheduled_at ASC
    `, [req.params.id]);
    res.json({ series: sRes.rows[0], matches: mRes.rows });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// POST /api/series — create series
router.post('/', authenticate, requireAdmin, async (req, res) => {
  const { name, short_name, series_type = 'Custom', description, season, start_date, end_date } = req.body;
  if (!name || !name.trim()) return res.status(400).json({ error: 'Series name is required' });
  try {
    const result = await global.db.query(
      `INSERT INTO series (name, short_name, series_type, description, season, start_date, end_date)
       VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING *`,
      [name.trim(), short_name?.trim() || null, series_type, description || null, season || null, start_date || null, end_date || null]
    );
    res.status(201).json(result.rows[0]);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// PUT /api/series/:id — update series
router.put('/:id', authenticate, requireAdmin, async (req, res) => {
  const { name, short_name, series_type, description, season, start_date, end_date, is_active } = req.body;
  if (!name || !name.trim()) return res.status(400).json({ error: 'Series name is required' });
  try {
    const result = await global.db.query(
      `UPDATE series SET name=$1, short_name=$2, series_type=$3, description=$4, season=$5,
        start_date=$6, end_date=$7, is_active=$8
       WHERE id=$9 RETURNING *`,
      [name.trim(), short_name?.trim() || null, series_type || 'Custom', description || null,
       season || null, start_date || null, end_date || null, is_active !== false, req.params.id]
    );
    if (!result.rows[0]) return res.status(404).json({ error: 'Series not found' });
    res.json(result.rows[0]);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// DELETE /api/series/:id — delete series (only if no matches linked)
router.delete('/:id', authenticate, requireAdmin, async (req, res) => {
  try {
    const mCheck = await global.db.query(
      'SELECT COUNT(*) as c FROM matches WHERE series_id=$1 AND deleted_at IS NULL', [req.params.id]
    );
    if (parseInt(mCheck.rows[0].c) > 0) {
      return res.status(400).json({ error: 'Cannot delete series with linked matches. Remove matches first or reassign them.' });
    }
    await global.db.query('DELETE FROM series WHERE id=$1', [req.params.id]);
    res.json({ success: true });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

module.exports = router;
