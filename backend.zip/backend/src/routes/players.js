const express = require('express');
const router = express.Router();
const { authenticate, requireAdmin } = require('../middleware/auth');

// GET /api/players
router.get('/', async (req, res) => {
  const { team_id, search } = req.query;
  let sql = `SELECT p.*, t.name as team_name, t.short_name as team_short
             FROM players p LEFT JOIN teams t ON p.team_id = t.id
             WHERE p.is_active = true AND p.deleted_at IS NULL`;
  const params = [];
  if (team_id) { sql += ` AND p.team_id = $${params.length + 1}`; params.push(team_id); }
  if (search) { sql += ` AND p.name ILIKE $${params.length + 1}`; params.push(`%${search}%`); }
  sql += ' ORDER BY p.name';
  try {
    const result = await global.db.query(sql, params);
    res.json(result.rows);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// GET /api/players/:id
router.get('/:id', async (req, res) => {
  try {
    const result = await global.db.query(
      `SELECT p.*, t.name as team_name FROM players p LEFT JOIN teams t ON p.team_id = t.id
       WHERE p.id = $1 AND p.deleted_at IS NULL`,
      [req.params.id]
    );
    if (!result.rows[0]) return res.status(404).json({ error: 'Player not found' });
    res.json(result.rows[0]);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// POST /api/players
router.post('/', authenticate, requireAdmin, async (req, res) => {
  const { name, short_name, nationality, batting_style, bowling_style, role, jersey_number, team_id, date_of_birth } = req.body;
  if (!name || !role) return res.status(400).json({ error: 'Player name and role required' });
  try {
    const result = await global.db.query(
      `INSERT INTO players (name, short_name, nationality, batting_style, bowling_style, role, jersey_number, team_id, date_of_birth)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING *`,
      [name.trim(), short_name?.trim() || null, nationality || null, batting_style || 'Right-hand bat',
       bowling_style || null, role, jersey_number || null, team_id || null, date_of_birth || null]
    );
    res.status(201).json(result.rows[0]);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// PUT /api/players/:id  (full update)
router.put('/:id', authenticate, requireAdmin, async (req, res) => {
  const { name, short_name, nationality, batting_style, bowling_style, role, jersey_number, team_id, date_of_birth } = req.body;
  if (!name || !role) return res.status(400).json({ error: 'Player name and role required' });
  try {
    const result = await global.db.query(
      `UPDATE players SET name=$1, short_name=$2, nationality=$3, batting_style=$4, bowling_style=$5,
       role=$6, jersey_number=$7, team_id=$8, date_of_birth=$9, updated_at=NOW()
       WHERE id=$10 AND deleted_at IS NULL RETURNING *`,
      [name.trim(), short_name?.trim() || null, nationality || null, batting_style || 'Right-hand bat',
       bowling_style || null, role, jersey_number || null, team_id || null, date_of_birth || null, req.params.id]
    );
    if (!result.rows[0]) return res.status(404).json({ error: 'Player not found' });
    res.json(result.rows[0]);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// PATCH /api/players/:id  (partial update)
router.patch('/:id', authenticate, requireAdmin, async (req, res) => {
  const allowed = ['name', 'short_name', 'nationality', 'batting_style', 'bowling_style', 'role', 'jersey_number', 'team_id', 'photo_url', 'is_active', 'date_of_birth'];
  const updates = []; const values = []; let idx = 1;
  Object.keys(req.body).forEach(k => {
    if (allowed.includes(k)) { updates.push(`${k}=$${idx++}`); values.push(req.body[k]); }
  });
  if (!updates.length) return res.status(400).json({ error: 'Nothing to update' });
  values.push(req.params.id);
  try {
    const result = await global.db.query(
      `UPDATE players SET ${updates.join(',')}, updated_at=NOW() WHERE id=$${idx} AND deleted_at IS NULL RETURNING *`,
      values
    );
    if (!result.rows[0]) return res.status(404).json({ error: 'Player not found' });
    res.json(result.rows[0]);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// DELETE /api/players/:id (soft delete)
router.delete('/:id', authenticate, requireAdmin, async (req, res) => {
  try {
    const result = await global.db.query(
      `UPDATE players SET deleted_at=NOW(), is_active=false, updated_at=NOW()
       WHERE id=$1 AND deleted_at IS NULL RETURNING id, name`,
      [req.params.id]
    );
    if (!result.rows[0]) return res.status(404).json({ error: 'Player not found' });
    res.json({ success: true, message: `Player "${result.rows[0].name}" deleted successfully` });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

module.exports = router;
