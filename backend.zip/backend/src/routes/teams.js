const express = require('express');
const router = express.Router();
const { authenticate, requireAdmin } = require('../middleware/auth');

// GET /api/teams
router.get('/', async (req, res) => {
  try {
    const result = await global.db.query(
      'SELECT * FROM teams WHERE deleted_at IS NULL ORDER BY name'
    );
    res.json(result.rows);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// GET /api/teams/:id
router.get('/:id', async (req, res) => {
  try {
    const result = await global.db.query(
      'SELECT * FROM teams WHERE id = $1 AND deleted_at IS NULL', [req.params.id]
    );
    if (!result.rows[0]) return res.status(404).json({ error: 'Team not found' });
    res.json(result.rows[0]);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// GET /api/teams/:id/players
router.get('/:id/players', async (req, res) => {
  try {
    const result = await global.db.query(
      'SELECT * FROM players WHERE team_id = $1 AND deleted_at IS NULL AND is_active = true ORDER BY name',
      [req.params.id]
    );
    res.json(result.rows);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// POST /api/teams
router.post('/', authenticate, requireAdmin, async (req, res) => {
  const { name, short_name, country, city, color_primary, color_secondary, logo_url } = req.body;
  if (!name || !short_name) return res.status(400).json({ error: 'Team name and short name required' });
  try {
    const result = await global.db.query(
      `INSERT INTO teams (name, short_name, country, city, color_primary, color_secondary, logo_url, created_by)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *`,
      [name.trim(), short_name.trim().toUpperCase(), country, city,
       color_primary || '#1a9c3e', color_secondary || '#ffffff', logo_url || null, req.user.id]
    );
    res.status(201).json(result.rows[0]);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// PUT /api/teams/:id  (full update)
router.put('/:id', authenticate, requireAdmin, async (req, res) => {
  const { name, short_name, country, city, color_primary, color_secondary, logo_url } = req.body;
  if (!name || !short_name) return res.status(400).json({ error: 'Team name and short name required' });
  try {
    const result = await global.db.query(
      `UPDATE teams SET name=$1, short_name=$2, country=$3, city=$4, color_primary=$5, color_secondary=$6, logo_url=$7, updated_at=NOW()
       WHERE id=$8 AND deleted_at IS NULL RETURNING *`,
      [name.trim(), short_name.trim().toUpperCase(), country, city,
       color_primary || '#1a9c3e', color_secondary || '#ffffff', logo_url || null, req.params.id]
    );
    if (!result.rows[0]) return res.status(404).json({ error: 'Team not found' });
    res.json(result.rows[0]);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// PATCH /api/teams/:id  (partial update)
router.patch('/:id', authenticate, requireAdmin, async (req, res) => {
  const allowed = ['name', 'short_name', 'country', 'city', 'color_primary', 'color_secondary', 'logo_url'];
  const updates = []; const values = []; let idx = 1;
  Object.keys(req.body).forEach(k => {
    if (allowed.includes(k)) { updates.push(`${k}=$${idx++}`); values.push(req.body[k]); }
  });
  if (!updates.length) return res.status(400).json({ error: 'Nothing to update' });
  values.push(req.params.id);
  try {
    const result = await global.db.query(
      `UPDATE teams SET ${updates.join(',')}, updated_at=NOW() WHERE id=$${idx} AND deleted_at IS NULL RETURNING *`,
      values
    );
    if (!result.rows[0]) return res.status(404).json({ error: 'Team not found' });
    res.json(result.rows[0]);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// DELETE /api/teams/:id (soft delete)
router.delete('/:id', authenticate, requireAdmin, async (req, res) => {
  try {
    // Check if team is used in any active/upcoming matches
    const activeMatch = await global.db.query(
      `SELECT id FROM matches WHERE (team_a_id=$1 OR team_b_id=$1) AND status IN ('upcoming','live','toss') AND deleted_at IS NULL`,
      [req.params.id]
    );
    if (activeMatch.rows.length > 0) {
      return res.status(409).json({
        error: 'Cannot delete team — it is assigned to active or upcoming matches. Complete or cancel those matches first.'
      });
    }

    const result = await global.db.query(
      `UPDATE teams SET deleted_at=NOW(), updated_at=NOW() WHERE id=$1 AND deleted_at IS NULL RETURNING id, name`,
      [req.params.id]
    );
    if (!result.rows[0]) return res.status(404).json({ error: 'Team not found' });
    res.json({ success: true, message: `Team "${result.rows[0].name}" deleted successfully` });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

module.exports = router;
