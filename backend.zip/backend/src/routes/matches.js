const express = require('express');
const router = express.Router();
const { authenticate, requireAdmin } = require('../middleware/auth');

router.get('/', async (req, res) => {
  const { status, series_id, limit = 20, offset = 0 } = req.query;
  try {
    let where = ['m.deleted_at IS NULL']; let params = []; let idx = 1;
    if (status === 'live') where.push(`m.status='live'`);
    else if (status === 'upcoming') where.push(`m.status IN ('upcoming','toss')`);
    else if (status === 'recent') where.push(`m.status IN ('completed','abandoned')`);
    else if (status) { where.push(`m.status=$${idx++}`); params.push(status); }
    if (series_id) { where.push(`m.series_id=$${idx++}`); params.push(series_id); }
    params.push(parseInt(limit), parseInt(offset));
    const sql = `SELECT m.*,ta.name as team_a_name,ta.short_name as team_a_short,ta.logo_url as team_a_logo,ta.color_primary as team_a_color,tb.name as team_b_name,tb.short_name as team_b_short,tb.logo_url as team_b_logo,tb.color_primary as team_b_color,COALESCE(v.name, m.venue_name) as venue_name,v.city as venue_city,m.venue_name as venue_name_text,s.name as series_name,s.short_name as series_short,tw.short_name as toss_winner_short,(SELECT row_to_json(i1) FROM (SELECT total_runs,total_wickets,total_overs,current_run_rate,required_run_rate,target,status as innings_status FROM innings WHERE match_id=m.id AND innings_number=m.current_innings LIMIT 1) i1) as current_innings_data,(SELECT row_to_json(i2) FROM (SELECT total_runs,total_wickets,total_overs,status as innings_status FROM innings WHERE match_id=m.id AND innings_number=1 LIMIT 1) i2) as innings1_data,(SELECT row_to_json(i3) FROM (SELECT total_runs,total_wickets,total_overs,status as innings_status,target FROM innings WHERE match_id=m.id AND innings_number=2 LIMIT 1) i3) as innings2_data FROM matches m JOIN teams ta ON m.team_a_id=ta.id JOIN teams tb ON m.team_b_id=tb.id LEFT JOIN venues v ON m.venue_id=v.id LEFT JOIN series s ON m.series_id=s.id LEFT JOIN teams tw ON m.toss_winner_id=tw.id WHERE ${where.join(' AND ')} ORDER BY CASE m.status WHEN 'live' THEN 1 WHEN 'toss' THEN 2 WHEN 'upcoming' THEN 3 ELSE 4 END,m.scheduled_at DESC LIMIT $${idx++} OFFSET $${idx++}`;
    const result = await global.db.query(sql, params);
    res.json(result.rows);
  } catch (e) { console.error(e); res.status(500).json({ error: e.message }); }
});

router.get('/:id', async (req, res) => {
  try {
    const matchResult = await global.db.query(`SELECT m.*,ta.name as team_a_name,ta.short_name as team_a_short,ta.logo_url as team_a_logo,ta.color_primary as team_a_color,tb.name as team_b_name,tb.short_name as team_b_short,tb.logo_url as team_b_logo,tb.color_primary as team_b_color,COALESCE(v.name, m.venue_name) as venue_name,v.city as venue_city,v.country as venue_country,m.venue_name as venue_name_text,s.name as series_name,s.short_name as series_short,tw.name as toss_winner_name,tw.short_name as toss_winner_short,w.name as winner_name,w.short_name as winner_short,mom.name as mom_name, mom.short_name as mom_short_name, motmt.name as mom_team_name FROM matches m JOIN teams ta ON m.team_a_id=ta.id JOIN teams tb ON m.team_b_id=tb.id LEFT JOIN venues v ON m.venue_id=v.id LEFT JOIN series s ON m.series_id=s.id LEFT JOIN teams tw ON m.toss_winner_id=tw.id LEFT JOIN teams w ON m.winner_id=w.id LEFT JOIN players mom ON m.man_of_match_id=mom.id LEFT JOIN teams motmt ON m.man_of_match_team_id=motmt.id WHERE m.id=$1 AND m.deleted_at IS NULL`, [req.params.id]);
    if (!matchResult.rows[0]) return res.status(404).json({ error: 'Match not found' });
    const match = matchResult.rows[0];
    const inningsResult = await global.db.query('SELECT * FROM innings WHERE match_id=$1 ORDER BY innings_number', [req.params.id]);
    const inningsData = await Promise.all(inningsResult.rows.map(async (inn) => {
      const [batters,bowlers,fow,parts,striker,nonStriker,bowler] = await Promise.all([
        global.db.query(`SELECT bs.*,p.name as player_name,p.short_name,db.name as dismissed_by_name,f.name as fielder_name FROM batter_stats bs JOIN players p ON bs.player_id=p.id LEFT JOIN players db ON bs.dismissed_by_id=db.id LEFT JOIN players f ON bs.fielder_id=f.id WHERE bs.innings_id=$1 ORDER BY bs.batting_order`,[inn.id]),
        global.db.query(`SELECT bws.*,p.name as player_name,p.short_name FROM bowler_stats bws JOIN players p ON bws.player_id=p.id WHERE bws.innings_id=$1 ORDER BY bws.overs_bowled DESC`,[inn.id]),
        global.db.query(`SELECT fow.*,p.name as player_name,p.short_name FROM fall_of_wickets fow JOIN players p ON fow.player_id=p.id WHERE fow.innings_id=$1 ORDER BY fow.wicket_number`,[inn.id]),
        global.db.query(`SELECT part.*,p1.name as batter1_name,p2.name as batter2_name FROM partnerships part JOIN players p1 ON part.batter1_id=p1.id JOIN players p2 ON part.batter2_id=p2.id WHERE part.innings_id=$1 ORDER BY part.wicket_number`,[inn.id]),
        inn.current_striker_id?global.db.query('SELECT id,name,short_name FROM players WHERE id=$1',[inn.current_striker_id]):{rows:[]},
        inn.current_non_striker_id?global.db.query('SELECT id,name,short_name FROM players WHERE id=$1',[inn.current_non_striker_id]):{rows:[]},
        inn.current_bowler_id?global.db.query('SELECT id,name,short_name FROM players WHERE id=$1',[inn.current_bowler_id]):{rows:[]}
      ]);
      return {...inn,batters:batters.rows,bowlers:bowlers.rows,fall_of_wickets:fow.rows,partnerships:parts.rows,current_striker:striker.rows[0]||null,current_non_striker:nonStriker.rows[0]||null,current_bowler:bowler.rows[0]||null};
    }));
    const squadsResult = await global.db.query(`SELECT sq.*,p.name as player_name,p.short_name,p.role,p.batting_style,p.bowling_style,p.jersey_number FROM squads sq JOIN players p ON sq.player_id=p.id WHERE sq.match_id=$1 ORDER BY sq.team_id,sq.batting_order NULLS LAST,p.name`,[req.params.id]);
    const commentaryResult = await global.db.query(`SELECT * FROM commentary WHERE match_id=$1 ORDER BY over_number DESC,ball_number DESC LIMIT 30`,[req.params.id]);
    res.json({match,innings:inningsData,squads:squadsResult.rows,commentary:commentaryResult.rows});
  } catch (e) { console.error(e); res.status(500).json({ error: e.message }); }
});

router.get('/:id/commentary', async (req, res) => {
  const { innings_number, limit=50, offset=0 } = req.query;
  try {
    let where='WHERE c.match_id=$1'; let params=[req.params.id];
    if (innings_number){where+=` AND i.innings_number=$2`;params.push(innings_number);}
    const result = await global.db.query(`SELECT c.*,i.innings_number FROM commentary c LEFT JOIN innings i ON c.innings_id=i.id ${where} ORDER BY c.over_number DESC,c.ball_number DESC LIMIT $${params.length+1} OFFSET $${params.length+2}`,[...params,limit,offset]);
    res.json(result.rows);
  } catch(e){res.status(500).json({error:e.message});}
});

router.post('/', authenticate, requireAdmin, async (req, res) => {
  const {series_id,match_number,match_type,overs_per_innings,venue_id,venue_name,team_a_id,team_b_id,scheduled_at,notes}=req.body;
  if (!team_a_id||!team_b_id) return res.status(400).json({error:'Both teams required'});
  if (team_a_id===team_b_id) return res.status(400).json({error:'Teams must be different'});
  try {
    const result = await global.db.query(`INSERT INTO matches (series_id,match_number,match_type,overs_per_innings,venue_id,venue_name,team_a_id,team_b_id,scheduled_at,notes,created_by) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11) RETURNING *`,[series_id||null,match_number||null,match_type||'T20',overs_per_innings||20,venue_id||null,venue_name||null,team_a_id,team_b_id,scheduled_at,notes||null,req.user.id]);
    res.status(201).json(result.rows[0]);
  } catch(e){console.error(e);res.status(500).json({error:e.message});}
});

router.patch('/:id', authenticate, requireAdmin, async (req, res) => {
  const allowed=['status','toss_winner_id','toss_decision','batting_first_team_id','result_text','winner_id','man_of_match_id','notes','venue_name','current_innings','overs_per_innings','match_type','scheduled_at'];
  const updates=[];const values=[];let idx=1;
  Object.keys(req.body).forEach(k=>{if(allowed.includes(k)){updates.push(`${k}=$${idx++}`);values.push(req.body[k]);}});
  if(!updates.length) return res.status(400).json({error:'No valid fields'});
  values.push(req.params.id);
  try {
    const result = await global.db.query(`UPDATE matches SET ${updates.join(',')},updated_at=NOW() WHERE id=$${idx} AND deleted_at IS NULL RETURNING *`,values);
    if(!result.rows[0]) return res.status(404).json({error:'Match not found'});
    global.broadcastMatch(req.params.id,{type:'match_update',match:result.rows[0]});
    res.json(result.rows[0]);
  } catch(e){res.status(500).json({error:e.message});}
});

router.delete('/:id', authenticate, requireAdmin, async (req, res) => {
  try {
    const active = await global.db.query(`SELECT id FROM matches WHERE id=$1 AND status IN ('live','toss') AND deleted_at IS NULL`,[req.params.id]);
    if(active.rows.length>0) return res.status(409).json({error:'Cannot delete a live match. End it first.'});
    const result = await global.db.query(`UPDATE matches SET deleted_at=NOW(),updated_at=NOW() WHERE id=$1 AND deleted_at IS NULL RETURNING id`,[req.params.id]);
    if(!result.rows[0]) return res.status(404).json({error:'Match not found'});
    res.json({success:true,message:'Match deleted successfully'});
  } catch(e){res.status(500).json({error:e.message});}
});

router.post('/:id/innings', authenticate, requireAdmin, async (req, res) => {
  const {innings_number,batting_team_id,bowling_team_id,target}=req.body;
  const client = await global.db.connect();
  try {
    await client.query('BEGIN');
    // GUARD: prevent more than 2 innings in a normal match
    const existingCount = await client.query('SELECT COUNT(*) as c FROM innings WHERE match_id=$1',[req.params.id]);
    if (parseInt(existingCount.rows[0].c) >= 2 && innings_number > 2) {
      await client.query('ROLLBACK');
      return res.status(400).json({error:'A match cannot have more than 2 innings. Use End Match to finalize.'});
    }
    const result = await client.query(`INSERT INTO innings (match_id,innings_number,batting_team_id,bowling_team_id,target,status) VALUES ($1,$2,$3,$4,$5,'in_progress') ON CONFLICT (match_id,innings_number) DO UPDATE SET status='in_progress',batting_team_id=$3,bowling_team_id=$4,target=$5 RETURNING *`,[req.params.id,innings_number,batting_team_id,bowling_team_id,target||null]);
    const inningsId=result.rows[0].id;
    const sqBat=await client.query(`SELECT player_id,batting_order FROM squads WHERE match_id=$1 AND team_id=$2 AND is_playing_xi=true ORDER BY batting_order`,[req.params.id,batting_team_id]);
    for(let i=0;i<sqBat.rows.length;i++){const sq=sqBat.rows[i];await client.query(`INSERT INTO batter_stats (innings_id,player_id,team_id,batting_order,status) VALUES ($1,$2,$3,$4,'yet_to_bat') ON CONFLICT DO NOTHING`,[inningsId,sq.player_id,batting_team_id,sq.batting_order||(i+1)]);}
    const sqBowl=await client.query(`SELECT player_id FROM squads WHERE match_id=$1 AND team_id=$2 AND is_playing_xi=true`,[req.params.id,bowling_team_id]);
    for(const sq of sqBowl.rows){await client.query(`INSERT INTO bowler_stats (innings_id,player_id,team_id) VALUES ($1,$2,$3) ON CONFLICT DO NOTHING`,[inningsId,sq.player_id,bowling_team_id]);}
    await client.query(`UPDATE matches SET status='live',setup_complete=true WHERE id=$1`,[req.params.id]);
    await client.query('COMMIT');
    res.status(201).json(result.rows[0]);
  } catch(e){await client.query('ROLLBACK');console.error(e);res.status(500).json({error:e.message});}
  finally{client.release();}
});

module.exports = router;
