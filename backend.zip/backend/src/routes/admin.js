const express = require('express');
const router = express.Router();
const { authenticate, requireAdmin } = require('../middleware/auth');

// GET /api/admin/dashboard
router.get('/dashboard', authenticate, requireAdmin, async (req, res) => {
  try {
    const [liveMatches, upcoming, completed, teams, players] = await Promise.all([
      global.db.query(`
        SELECT m.id, m.status, m.squads_assigned, m.setup_complete,
          ta.short_name as team_a, tb.short_name as team_b, m.scheduled_at
        FROM matches m JOIN teams ta ON m.team_a_id=ta.id JOIN teams tb ON m.team_b_id=tb.id
        WHERE m.status IN ('live','toss') AND m.deleted_at IS NULL ORDER BY m.scheduled_at DESC`),
      global.db.query(`SELECT COUNT(*) as count FROM matches WHERE status='upcoming' AND deleted_at IS NULL`),
      global.db.query(`SELECT COUNT(*) as count FROM matches WHERE status='completed' AND deleted_at IS NULL`),
      global.db.query(`SELECT COUNT(*) as count FROM teams WHERE deleted_at IS NULL`),
      global.db.query(`SELECT COUNT(*) as count FROM players WHERE is_active=true AND deleted_at IS NULL`)
    ]);
    res.json({
      liveMatches: liveMatches.rows,
      stats: {
        live: liveMatches.rows.length,
        upcoming: parseInt(upcoming.rows[0].count),
        completed: parseInt(completed.rows[0].count),
        teams: parseInt(teams.rows[0].count),
        players: parseInt(players.rows[0].count)
      }
    });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// GET /api/admin/matches
router.get('/matches', authenticate, requireAdmin, async (req, res) => {
  try {
    const result = await global.db.query(`
      SELECT m.*,
        COALESCE(v.name, m.venue_name) as venue_name, v.city as venue_city, m.venue_name as venue_name_text,
        ta.short_name as team_a_short, tb.short_name as team_b_short,
        ta.name as team_a_name, tb.name as team_b_name,
        ta.color_primary as team_a_color, tb.color_primary as team_b_color,
        s.name as series_name,
        (SELECT COUNT(*) FROM squads WHERE match_id=m.id) as squad_count
      FROM matches m JOIN teams ta ON m.team_a_id=ta.id JOIN teams tb ON m.team_b_id=tb.id
      LEFT JOIN venues v ON m.venue_id=v.id
      LEFT JOIN series s ON m.series_id=s.id
      WHERE m.deleted_at IS NULL ORDER BY m.scheduled_at DESC LIMIT 50
    `);
    res.json(result.rows);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// GET /api/admin/matches/:id/setup-checklist
router.get('/matches/:id/setup-checklist', authenticate, requireAdmin, async (req, res) => {
  try {
    const matchRes = await global.db.query(
      `SELECT m.*, ta.name as team_a_name, tb.name as team_b_name
       FROM matches m JOIN teams ta ON m.team_a_id=ta.id JOIN teams tb ON m.team_b_id=tb.id
       WHERE m.id=$1 AND m.deleted_at IS NULL`, [req.params.id]
    );
    if (!matchRes.rows[0]) return res.status(404).json({ error: 'Match not found' });
    const match = matchRes.rows[0];

    const [tpA, tpB, sqA, sqB] = await Promise.all([
      global.db.query(`SELECT COUNT(*) as c FROM players WHERE team_id=$1 AND is_active=true AND deleted_at IS NULL`, [match.team_a_id]),
      global.db.query(`SELECT COUNT(*) as c FROM players WHERE team_id=$1 AND is_active=true AND deleted_at IS NULL`, [match.team_b_id]),
      global.db.query(`SELECT COUNT(*) as c FROM squads WHERE match_id=$1 AND team_id=$2 AND is_playing_xi=true`, [req.params.id, match.team_a_id]),
      global.db.query(`SELECT COUNT(*) as c FROM squads WHERE match_id=$1 AND team_id=$2 AND is_playing_xi=true`, [req.params.id, match.team_b_id])
    ]);

    const counts = {
      team_a_players: parseInt(tpA.rows[0].c),
      team_b_players: parseInt(tpB.rows[0].c),
      squad_a_xi: parseInt(sqA.rows[0].c),
      squad_b_xi: parseInt(sqB.rows[0].c)
    };

    res.json({
      match,
      checklist: {
        teams_selected: !!(match.team_a_id && match.team_b_id),
        team_a_has_players: counts.team_a_players >= 11,
        team_b_has_players: counts.team_b_players >= 11,
        squad_a_assigned: counts.squad_a_xi >= 11,
        squad_b_assigned: counts.squad_b_xi >= 11,
        toss_done: !!(match.toss_winner_id && match.toss_decision),
        ready_to_score: counts.squad_a_xi >= 11 && counts.squad_b_xi >= 11 && !!(match.toss_winner_id)
      },
      counts
    });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// GET /api/admin/matches/:id/squads
router.get('/matches/:id/squads', authenticate, requireAdmin, async (req, res) => {
  try {
    const result = await global.db.query(`
      SELECT sq.*, p.name as player_name, p.short_name, p.role,
        p.batting_style, p.bowling_style, p.jersey_number
      FROM squads sq JOIN players p ON sq.player_id=p.id
      WHERE sq.match_id=$1 ORDER BY sq.team_id, sq.batting_order NULLS LAST, p.name
    `, [req.params.id]);
    res.json(result.rows);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// POST /api/admin/matches/:id/squads — assign squad for one team
router.post('/matches/:id/squads', authenticate, requireAdmin, async (req, res) => {
  const { team_id, players } = req.body;
  if (!team_id || !players || !Array.isArray(players) || players.length === 0)
    return res.status(400).json({ error: 'team_id and players array required' });
  if (players.length < 11)
    return res.status(400).json({ error: 'At least 11 players required for Playing XI' });

  // Validate: captain and vice-captain must be different players
  const captainIds = players.filter(p => p.is_captain).map(p => p.player_id);
  const vcIds = players.filter(p => p.is_vice_captain).map(p => p.player_id);
  if (captainIds.length > 0 && vcIds.length > 0 && captainIds[0] === vcIds[0]) {
    return res.status(400).json({ error: 'Captain and Vice-Captain must be different players' });
  }

  const client = await global.db.connect();
  try {
    await client.query('BEGIN');
    await client.query('DELETE FROM squads WHERE match_id=$1 AND team_id=$2', [req.params.id, team_id]);

    for (let i = 0; i < players.length; i++) {
      const p = players[i];
      await client.query(`
        INSERT INTO squads (match_id, team_id, player_id, is_playing_xi, is_captain, is_vice_captain, is_wicketkeeper, batting_order)
        VALUES ($1,$2,$3,$4,$5,$6,$7,$8)
      `, [req.params.id, team_id, p.player_id,
          p.is_playing_xi !== false,
          p.is_captain || false,
          p.is_vice_captain || false,
          p.is_wicketkeeper || false,
          p.batting_order || (i + 1)]);
    }

    const matchRes = await client.query('SELECT team_a_id, team_b_id FROM matches WHERE id=$1', [req.params.id]);
    const m = matchRes.rows[0];
    const [sqA, sqB] = await Promise.all([
      client.query(`SELECT COUNT(*) as c FROM squads WHERE match_id=$1 AND team_id=$2 AND is_playing_xi=true`, [req.params.id, m.team_a_id]),
      client.query(`SELECT COUNT(*) as c FROM squads WHERE match_id=$1 AND team_id=$2 AND is_playing_xi=true`, [req.params.id, m.team_b_id])
    ]);
    const bothDone = parseInt(sqA.rows[0].c) >= 11 && parseInt(sqB.rows[0].c) >= 11;
    if (bothDone) await client.query(`UPDATE matches SET squads_assigned=true WHERE id=$1`, [req.params.id]);

    await client.query('COMMIT');
    res.json({ success: true, count: players.length, both_squads_assigned: bothDone });
  } catch (e) {
    await client.query('ROLLBACK');
    res.status(500).json({ error: e.message });
  } finally {
    client.release();
  }
});

// ============================================================
// GET /api/admin/matches/:id/scoring-state
// BUG FIX: Removed stale load() triggers, guaranteed batter seeding
// ============================================================
router.get('/matches/:id/scoring-state', authenticate, requireAdmin, async (req, res) => {
  try {
    const matchRes = await global.db.query(`
      SELECT m.*,
        ta.id as team_a_id, ta.name as team_a_name, ta.short_name as team_a_short, ta.color_primary as team_a_color,
        tb.id as team_b_id, tb.name as team_b_name, tb.short_name as team_b_short, tb.color_primary as team_b_color
      FROM matches m
      JOIN teams ta ON m.team_a_id=ta.id JOIN teams tb ON m.team_b_id=tb.id
      WHERE m.id=$1 AND m.deleted_at IS NULL
    `, [req.params.id]);
    if (!matchRes.rows[0]) return res.status(404).json({ error: 'Match not found' });
    const match = matchRes.rows[0];

    // Get the MOST RECENT in-progress innings (or last innings if completed)
    const inningsRes = await global.db.query(
      `SELECT * FROM innings WHERE match_id=$1
       ORDER BY CASE status WHEN 'in_progress' THEN 0 ELSE 1 END, innings_number DESC LIMIT 1`,
      [req.params.id]
    );
    const innings = inningsRes.rows[0] || null;
    const activeInnings = innings?.status === 'in_progress' ? innings : null;

    // Squad players — always from squads table
    const squadsRes = await global.db.query(`
      SELECT sq.player_id, sq.team_id, sq.is_captain, sq.is_wicketkeeper,
        sq.batting_order, sq.is_playing_xi,
        p.name, p.short_name, p.role, p.batting_style, p.bowling_style
      FROM squads sq JOIN players p ON sq.player_id=p.id
      WHERE sq.match_id=$1 AND sq.is_playing_xi=true
      ORDER BY sq.team_id, sq.batting_order NULLS LAST, p.name
    `, [req.params.id]);
    const allSquad = squadsRes.rows;
    const squadA = allSquad.filter(p => p.team_id === match.team_a_id);
    const squadB = allSquad.filter(p => p.team_id === match.team_b_id);

    const battingTeamId = activeInnings?.batting_team_id || innings?.batting_team_id || match.batting_first_team_id || null;
    const bowlingTeamId = activeInnings?.bowling_team_id || innings?.bowling_team_id ||
      (battingTeamId === match.team_a_id ? match.team_b_id
       : battingTeamId === match.team_b_id ? match.team_a_id : null);

    const battingSquad = battingTeamId ? allSquad.filter(p => p.team_id === battingTeamId) : [];
    const bowlingSquad = bowlingTeamId ? allSquad.filter(p => p.team_id === bowlingTeamId) : [];

    let batters = [], bowlers = [], availableBowlers = bowlingSquad, recentDeliveries = [];

    if (activeInnings) {
      // ── FIX: Seed batter_stats synchronously within the same request ──
      const bsCheck = await global.db.query(
        `SELECT COUNT(*) as c FROM batter_stats WHERE innings_id=$1`, [activeInnings.id]
      );
      if (parseInt(bsCheck.rows[0].c) === 0 && battingSquad.length > 0) {
        // Use a single multi-row insert to avoid race conditions
        const values = battingSquad.map((p, i) =>
          `('${activeInnings.id}','${p.player_id}','${battingTeamId}',${p.batting_order || (i + 1)},'yet_to_bat')`
        ).join(',');
        await global.db.query(`
          INSERT INTO batter_stats (innings_id, player_id, team_id, batting_order, status)
          VALUES ${values} ON CONFLICT DO NOTHING
        `);
      }

      // Seed bowler_stats synchronously
      const bwCheck = await global.db.query(
        `SELECT COUNT(*) as c FROM bowler_stats WHERE innings_id=$1`, [activeInnings.id]
      );
      if (parseInt(bwCheck.rows[0].c) === 0 && bowlingSquad.length > 0) {
        const values = bowlingSquad.map(p =>
          `('${activeInnings.id}','${p.player_id}','${bowlingTeamId}')`
        ).join(',');
        await global.db.query(`
          INSERT INTO bowler_stats (innings_id, player_id, team_id)
          VALUES ${values} ON CONFLICT DO NOTHING
        `);
      }

      const [bRes, bwRes, dlRes] = await Promise.all([
        global.db.query(
          `SELECT bs.*, p.name, p.short_name FROM batter_stats bs
           JOIN players p ON bs.player_id=p.id
           WHERE bs.innings_id=$1 ORDER BY bs.batting_order NULLS LAST`,
          [activeInnings.id]
        ),
        global.db.query(
          `SELECT bws.*, p.name, p.short_name FROM bowler_stats bws
           JOIN players p ON bws.player_id=p.id
           WHERE bws.innings_id=$1 ORDER BY bws.overs_bowled DESC`,
          [activeInnings.id]
        ),
        global.db.query(
          `SELECT d.*, p.name as striker_name, b.name as bowler_name
           FROM deliveries d
           JOIN players p ON d.striker_id=p.id
           JOIN players b ON d.bowler_id=b.id
           WHERE d.innings_id=$1 ORDER BY d.created_at DESC LIMIT 12`,
          [activeInnings.id]
        )
      ]);

      batters = bRes.rows;
      bowlers = bwRes.rows;
      recentDeliveries = dlRes.rows.reverse();

      availableBowlers = bowlingSquad.map(sq => {
        const st = bwRes.rows.find(b => b.player_id === sq.player_id);
        return {
          player_id: sq.player_id, name: sq.name, short_name: sq.short_name,
          bowling_style: sq.bowling_style,
          overs_bowled: st?.overs_bowled || 0,
          balls_bowled: st?.balls_bowled || 0,
          runs_conceded: st?.runs_conceded || 0,
          wickets: st?.wickets || 0,
          economy: st?.economy || 0
        };
      });
    }

    // ── FIX: Always read current players from innings row, not from memory ──
    const inningsForPlayers = activeInnings || innings;
    const [striker, nonStriker, curBowler] = await Promise.all([
      inningsForPlayers?.current_striker_id
        ? global.db.query('SELECT id,name,short_name FROM players WHERE id=$1', [inningsForPlayers.current_striker_id])
        : { rows: [null] },
      inningsForPlayers?.current_non_striker_id
        ? global.db.query('SELECT id,name,short_name FROM players WHERE id=$1', [inningsForPlayers.current_non_striker_id])
        : { rows: [null] },
      inningsForPlayers?.current_bowler_id
        ? global.db.query('SELECT id,name,short_name FROM players WHERE id=$1', [inningsForPlayers.current_bowler_id])
        : { rows: [null] }
    ]);

    // All innings for this match (for end-match panel)
    const allInningsRes = await global.db.query(
      `SELECT i.*, bt.name as batting_team_name, bt.short_name as batting_team_short
       FROM innings i JOIN teams bt ON i.batting_team_id=bt.id
       WHERE i.match_id=$1 ORDER BY i.innings_number`,
      [req.params.id]
    );

    res.json({
      match,
      innings: activeInnings,          // active in-progress innings
      allInnings: allInningsRes.rows,   // all innings for display
      batters,
      bowlers,
      availableBowlers,
      recentDeliveries,
      currentStriker: striker.rows[0] || null,
      currentNonStriker: nonStriker.rows[0] || null,
      currentBowler: curBowler.rows[0] || null,
      squadA, squadB, battingSquad, bowlingSquad,
      squadsReady: squadA.length >= 11 && squadB.length >= 11,
      battingTeamId, bowlingTeamId
    });
  } catch (e) {
    console.error('scoring-state error:', e);
    res.status(500).json({ error: e.message });
  }
});

// ============================================================
// POST /api/admin/matches/:id/end-match
// BUG FIX: New endpoint — finalizes match, saves result
// ============================================================
router.post('/matches/:id/end-match', authenticate, requireAdmin, async (req, res) => {
  const { result_type, winner_team_id, result_text, abandon_reason } = req.body;
  // result_type: 'normal' | 'tie' | 'no_result' | 'abandoned'

  const client = await global.db.connect();
  try {
    await client.query('BEGIN');

    const matchRes = await client.query(
      `SELECT m.*, ta.name as team_a_name, ta.short_name as team_a_short,
         tb.name as team_b_name, tb.short_name as team_b_short
       FROM matches m JOIN teams ta ON m.team_a_id=ta.id JOIN teams tb ON m.team_b_id=tb.id
       WHERE m.id=$1 AND m.deleted_at IS NULL`,
      [req.params.id]
    );
    if (!matchRes.rows[0]) { await client.query('ROLLBACK'); return res.status(404).json({ error: 'Match not found' }); }
    const match = matchRes.rows[0];

    if (match.status === 'completed') {
      await client.query('ROLLBACK');
      return res.status(400).json({ error: 'Match is already completed' });
    }

    // End any in-progress innings
    await client.query(
      `UPDATE innings SET status='completed', all_out=false WHERE match_id=$1 AND status='in_progress'`,
      [req.params.id]
    );

    // Get all innings for result calculation
    const inningsRes = await client.query(
      `SELECT * FROM innings WHERE match_id=$1 ORDER BY innings_number`,
      [req.params.id]
    );
    const allInnings = inningsRes.rows;

    // Auto-calculate result if not provided
    let finalResultText = result_text;
    let winnerId = winner_team_id || null;
    let finalStatus = 'completed';

    if (result_type === 'abandoned') {
      finalStatus = 'abandoned';
      finalResultText = abandon_reason ? `Match abandoned — ${abandon_reason}` : 'Match abandoned';
      winnerId = null;
    } else if (result_type === 'no_result') {
      finalResultText = 'No result';
      winnerId = null;
    } else if (result_type === 'tie') {
      finalResultText = 'Match tied';
      winnerId = null;
    } else {
      // Normal result — auto-calculate if both innings played
      if (!finalResultText && allInnings.length >= 2) {
        const inn1 = allInnings[0]; // first innings
        const inn2 = allInnings[1]; // second innings
        const team1 = inn1.batting_team_id === match.team_a_id ? match.team_a_short : match.team_b_short;
        const team2 = inn2.batting_team_id === match.team_a_id ? match.team_a_short : match.team_b_short;

        if (inn2.total_runs > inn1.total_runs) {
          // Team 2 won (chasing)
          winnerId = winnerId || inn2.batting_team_id;
          const wicketsLeft = 10 - inn2.total_wickets;
          finalResultText = `${team2} won by ${wicketsLeft} wicket${wicketsLeft !== 1 ? 's' : ''}`;
        } else if (inn1.total_runs > inn2.total_runs) {
          // Team 1 won (defending)
          winnerId = winnerId || inn1.batting_team_id;
          const runMargin = inn1.total_runs - inn2.total_runs;
          finalResultText = `${team1} won by ${runMargin} run${runMargin !== 1 ? 's' : ''}`;
        } else {
          finalResultText = 'Match tied';
          winnerId = null;
        }
      } else if (!finalResultText && allInnings.length === 1) {
        // Only one innings played
        const inn1 = allInnings[0];
        const teamName = inn1.batting_team_id === match.team_a_id ? match.team_a_short : match.team_b_short;
        finalResultText = `${teamName} ${inn1.total_runs}/${inn1.total_wickets} (${inn1.total_overs} ov) — Match ended`;
      }
    }

    // Update match to completed
    await client.query(`
      UPDATE matches SET
        status=$1,
        winner_id=$2,
        result_text=$3,
        updated_at=NOW()
      WHERE id=$4
    `, [finalStatus, winnerId || null, finalResultText || 'Match ended', req.params.id]);

    await client.query('COMMIT');

    // Broadcast match end to all WebSocket clients
    global.broadcastMatch(req.params.id, {
      type: 'match_ended',
      matchId: req.params.id,
      status: finalStatus,
      result: finalResultText,
      winner_id: winnerId
    });

    res.json({
      success: true,
      status: finalStatus,
      result_text: finalResultText,
      winner_id: winnerId
    });
  } catch (e) {
    await client.query('ROLLBACK');
    console.error('end-match error:', e);
    res.status(500).json({ error: e.message });
  } finally {
    client.release();
  }
});

// ============================================================
// POST /api/admin/matches/:id/resume-match
// Allows admin to re-open a completed match for corrections
// ============================================================
router.post('/matches/:id/resume-match', authenticate, requireAdmin, async (req, res) => {
  try {
    await global.db.query(
      `UPDATE matches SET status='live', winner_id=NULL, result_text=NULL, updated_at=NOW() WHERE id=$1 AND status IN ('completed','abandoned')`,
      [req.params.id]
    );
    // Re-open last innings
    await global.db.query(
      `UPDATE innings SET status='in_progress' WHERE match_id=$1 AND innings_number=(SELECT MAX(innings_number) FROM innings WHERE match_id=$1)`,
      [req.params.id]
    );
    res.json({ success: true, message: 'Match resumed for correction' });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// ============================================================
// GET /api/admin/matches/:id/motm-candidates
// Returns winner team squad with their match stats for MOTM selection
// ============================================================
router.get('/matches/:id/motm-candidates', authenticate, requireAdmin, async (req, res) => {
  try {
    const matchRes = await global.db.query(
      `SELECT m.*, ta.name as team_a_name, tb.name as team_b_name
       FROM matches m JOIN teams ta ON m.team_a_id=ta.id JOIN teams tb ON m.team_b_id=tb.id
       WHERE m.id=$1 AND m.deleted_at IS NULL`,
      [req.params.id]
    );
    if (!matchRes.rows[0]) return res.status(404).json({ error: 'Match not found' });
    const match = matchRes.rows[0];

    // Determine eligible team(s)
    const isTied    = !match.winner_id && match.status === 'completed';
    const isNoResult = match.status === 'abandoned' || match.result_text === 'No result';
    const winnerId  = match.winner_id || null;

    // For ties/no-result, allow both teams; for normal result only winner
    const eligibleTeamIds = winnerId
      ? [winnerId]
      : (isTied ? [match.team_a_id, match.team_b_id] : []);

    if (eligibleTeamIds.length === 0) {
      return res.json({
        can_select: false,
        reason: isNoResult ? 'no_result' : 'no_winner',
        candidates: [],
        winner_team_name: null,
        is_tie: isTied,
        match_status: match.status
      });
    }

    // Fetch candidates: squad players from eligible team(s) with their stats
    const candidates = [];
    for (const teamId of eligibleTeamIds) {
      const squadRes = await global.db.query(`
        SELECT sq.player_id, sq.is_captain, sq.is_vice_captain, sq.is_wicketkeeper, sq.batting_order,
          p.name, p.short_name, p.role,
          t.name as team_name, t.id as team_id
        FROM squads sq
        JOIN players p ON sq.player_id = p.id
        JOIN teams t ON sq.team_id = t.id
        WHERE sq.match_id = $1 AND sq.team_id = $2 AND sq.is_playing_xi = true
        ORDER BY sq.batting_order NULLS LAST, p.name
      `, [req.params.id, teamId]);

      for (const player of squadRes.rows) {
        // Aggregate batting stats across all innings for this player in this match
        const batRes = await global.db.query(`
          SELECT COALESCE(SUM(bs.runs), 0) as runs,
                 COALESCE(SUM(bs.balls_faced), 0) as balls_faced,
                 COALESCE(SUM(bs.fours), 0) as fours,
                 COALESCE(SUM(bs.sixes), 0) as sixes,
                 MAX(bs.strike_rate) as strike_rate
          FROM batter_stats bs
          JOIN innings i ON bs.innings_id = i.id
          WHERE i.match_id = $1 AND bs.player_id = $2
        `, [req.params.id, player.player_id]);

        // Aggregate bowling stats
        const bowlRes = await global.db.query(`
          SELECT COALESCE(SUM(bws.wickets), 0) as wickets,
                 COALESCE(SUM(bws.runs_conceded), 0) as runs_conceded,
                 COALESCE(SUM(bws.balls_bowled), 0) as balls_bowled,
                 MAX(bws.economy) as economy,
                 COALESCE(SUM(bws.maidens), 0) as maidens
          FROM bowler_stats bws
          JOIN innings i ON bws.innings_id = i.id
          WHERE i.match_id = $1 AND bws.player_id = $2
        `, [req.params.id, player.player_id]);

        const bat  = batRes.rows[0];
        const bowl = bowlRes.rows[0];

        // Format overs from balls
        const ballsBowled = parseInt(bowl.balls_bowled) || 0;
        const oversBowled = ballsBowled > 0
          ? `${Math.floor(ballsBowled / 6)}.${ballsBowled % 6}`
          : '0';

        candidates.push({
          player_id:      player.player_id,
          name:           player.name,
          short_name:     player.short_name,
          role:           player.role,
          team_id:        player.team_id,
          team_name:      player.team_name,
          is_captain:     player.is_captain,
          is_vice_captain: player.is_vice_captain,
          is_wicketkeeper: player.is_wicketkeeper,
          // Stats
          runs:           parseInt(bat.runs) || 0,
          balls_faced:    parseInt(bat.balls_faced) || 0,
          fours:          parseInt(bat.fours) || 0,
          sixes:          parseInt(bat.sixes) || 0,
          strike_rate:    parseFloat(bat.strike_rate) || 0,
          wickets:        parseInt(bowl.wickets) || 0,
          runs_conceded:  parseInt(bowl.runs_conceded) || 0,
          overs_bowled:   oversBowled,
          economy:        parseFloat(bowl.economy) || 0,
          maidens:        parseInt(bowl.maidens) || 0,
        });
      }
    }

    const winnerTeamName = winnerId
      ? (winnerId === match.team_a_id ? match.team_a_name : match.team_b_name)
      : null;

    res.json({
      can_select: true,
      is_tie: isTied,
      winner_id: winnerId,
      winner_team_name: winnerTeamName,
      current_motm_id: match.man_of_match_id || null,
      candidates,
      match_status: match.status
    });
  } catch (e) {
    console.error('motm-candidates error:', e);
    res.status(500).json({ error: e.message });
  }
});

// ============================================================
// POST /api/admin/matches/:id/set-motm
// Save Man of the Match selection
// ============================================================
router.post('/matches/:id/set-motm', authenticate, requireAdmin, async (req, res) => {
  const { player_id } = req.body;

  try {
    const matchRes = await global.db.query(
      `SELECT m.* FROM matches m WHERE m.id=$1 AND m.deleted_at IS NULL`,
      [req.params.id]
    );
    if (!matchRes.rows[0]) return res.status(404).json({ error: 'Match not found' });
    const match = matchRes.rows[0];

    if (!['completed', 'abandoned'].includes(match.status)) {
      return res.status(400).json({ error: 'Match must be completed before selecting Man of the Match' });
    }

    if (!player_id) {
      // Allow clearing MOTM
      await global.db.query(
        `UPDATE matches SET man_of_match_id=NULL, man_of_match_team_id=NULL, updated_at=NOW() WHERE id=$1`,
        [req.params.id]
      );
      return res.json({ success: true, man_of_match_id: null });
    }

    // Validate: player must be in the match squad
    const squadCheck = await global.db.query(
      `SELECT sq.player_id, sq.team_id FROM squads sq WHERE sq.match_id=$1 AND sq.player_id=$2 AND sq.is_playing_xi=true`,
      [req.params.id, player_id]
    );
    if (!squadCheck.rows[0]) {
      return res.status(400).json({ error: 'Selected player is not in the match squad' });
    }

    // If there's a winner, validate player belongs to winner team
    if (match.winner_id) {
      const playerTeamId = squadCheck.rows[0].team_id;
      if (playerTeamId !== match.winner_id) {
        return res.status(400).json({ error: 'Man of the Match must be from the winning team' });
      }
    }

    const playerTeamId = squadCheck.rows[0].team_id;

    await global.db.query(
      `UPDATE matches SET man_of_match_id=$1, man_of_match_team_id=$2, updated_at=NOW() WHERE id=$3`,
      [player_id, playerTeamId, req.params.id]
    );

    // Fetch player name for response
    const playerRes = await global.db.query(
      'SELECT name, short_name FROM players WHERE id=$1',
      [player_id]
    );

    res.json({
      success: true,
      man_of_match_id: player_id,
      man_of_match_name: playerRes.rows[0]?.name || null
    });
  } catch (e) {
    console.error('set-motm error:', e);
    res.status(500).json({ error: e.message });
  }
});

module.exports = router;
