const express = require('express');
const router = express.Router();
const { authenticate, requireAdmin } = require('../middleware/auth');
const engine = require('../services/scoringEngine');

// ─────────────────────────────────────────────────────────────
// POST /api/scoring/delivery — Record a ball
//
// BUG FIXES IN THIS REWRITE:
// A) batter_stats UPDATE used raw JS booleans inside SQL strings
//    → Fixed: use parameterised queries, no raw string interpolation
// B) non_striker_id NOT NULL — null would crash transaction
//    → Fixed: validate non_striker_id before insert; allow null only if DB permits
// C) Strike-rate formula in UPDATE used column alias in same SET clause
//    → Fixed: compute strike_rate in JS, pass as parameter
// D) Commentary called with wrong object shape
//    → Fixed: pass all named params to new generateCommentary()
// E) Silent catch on batter update when batterUpdateFields was empty
//    → Fixed: guard before calling UPDATE
// ─────────────────────────────────────────────────────────────
router.post('/delivery', authenticate, requireAdmin, async (req, res) => {
  const client = await global.db.connect();
  try {
    await client.query('BEGIN');

    const {
      innings_id,
      striker_id, non_striker_id, bowler_id,
      runs_off_bat = 0,
      extra_type = null,
      wide_runs = 0, no_ball_runs = 0, bye_runs = 0, leg_bye_runs = 0,
      is_wicket = false, wicket_type = null,
      dismissed_player_id = null, fielder_id = null, second_fielder_id = null,
      commentary: customCommentary = null,
      rotate_strike_override = null
    } = req.body;

    // ── Validate required fields ─────────────────────────────
    if (!innings_id)   throw new Error('innings_id is required');
    if (!striker_id)   throw new Error('striker_id is required');
    if (!bowler_id)    throw new Error('bowler_id is required');
    // non_striker_id required only for innings (not for tail)
    // but deliveries.non_striker_id is NOT NULL — so we must provide it
    if (!non_striker_id) throw new Error('non_striker_id is required. Set both openers before scoring.');

    // ── Fetch innings + match ────────────────────────────────
    const inningsRes = await client.query(
      `SELECT i.*, m.overs_per_innings, m.match_type, m.id as match_id, m.status as match_status
       FROM innings i JOIN matches m ON i.match_id = m.id WHERE i.id = $1`,
      [innings_id]
    );
    if (!inningsRes.rows[0]) throw new Error('Innings not found');
    const innings = inningsRes.rows[0];

    if (innings.status !== 'in_progress') throw new Error(`Innings is not in progress (status: ${innings.status})`);
    if (innings.match_status === 'completed') throw new Error('Match is already completed');

    // ── Calculate delivery totals ────────────────────────────
    const { extras_total, total_runs, is_legal_ball } = engine.calculateDeliveryTotals({
      runs_off_bat, extra_type, wide_runs, no_ball_runs, bye_runs, leg_bye_runs
    });

    // ── Determine over/ball context ──────────────────────────
    const currentLegalBalls = innings.total_balls || 0;
    const currentOverNumber  = Math.floor(currentLegalBalls / 6);
    const newLegalBalls      = is_legal_ball ? currentLegalBalls + 1 : currentLegalBalls;

    // ── Get or create current over ───────────────────────────
    let overRes = await client.query(
      'SELECT * FROM overs WHERE innings_id = $1 AND over_number = $2',
      [innings_id, currentOverNumber]
    );

    let currentOver;
    if (!overRes.rows[0]) {
      const newOver = await client.query(
        'INSERT INTO overs (innings_id, over_number, bowler_id) VALUES ($1,$2,$3) RETURNING *',
        [innings_id, currentOverNumber, bowler_id]
      );
      currentOver = newOver.rows[0];
    } else {
      currentOver = overRes.rows[0];
    }

    const legalBallsInOver = currentOver.legal_balls || 0;
    const ballDisplay = `${currentOverNumber + 1}.${legalBallsInOver + (is_legal_ball ? 1 : 0)}`;

    // ── Fetch player names for commentary ─────────────────────
    const [strikerRes, bowlerRes, fielderRes, nonStrikerRes] = await Promise.all([
      client.query('SELECT id, name, short_name FROM players WHERE id = $1', [striker_id]),
      client.query('SELECT id, name, short_name FROM players WHERE id = $1', [bowler_id]),
      fielder_id
        ? client.query('SELECT id, name, short_name FROM players WHERE id = $1', [fielder_id])
        : { rows: [null] },
      non_striker_id
        ? client.query('SELECT id, name, short_name FROM players WHERE id = $1', [non_striker_id])
        : { rows: [null] }
    ]);

    const strikerName    = strikerRes.rows[0]?.name    || 'Batter';
    const bowlerName     = bowlerRes.rows[0]?.name     || 'Bowler';
    const fielderName    = fielderRes.rows[0]?.name    || null;
    const nonStrikerName = nonStrikerRes.rows[0]?.name || null;

    // ── Score state after delivery ────────────────────────────
    const newTeamScore  = (innings.total_runs    || 0) + total_runs;
    const newWickets    = is_wicket ? (innings.total_wickets || 0) + 1 : (innings.total_wickets || 0);

    // ── Fetch current batter stats for milestone detection ────
    const strikerStatsRes = await client.query(
      'SELECT runs, balls_faced FROM batter_stats WHERE innings_id = $1 AND player_id = $2',
      [innings_id, striker_id]
    );
    const strikerRunsBefore  = strikerStatsRes.rows[0]?.runs        || 0;
    const strikerBallsBefore = strikerStatsRes.rows[0]?.balls_faced || 0;

    // Runs credited to batter
    const runsForBatter = (extra_type === 'bye' || extra_type === 'leg_bye' || extra_type === 'wide') ? 0 : runs_off_bat;
    const strikerRunsAfter  = strikerRunsBefore  + runsForBatter;
    const strikerBallsAfter = strikerBallsBefore + (extra_type === 'wide' ? 0 : (is_legal_ball || extra_type === 'no_ball' ? 1 : 0));

    // ── Generate auto commentary ──────────────────────────────
    const autoCommentary = engine.generateCommentary({
      display_ball:        ballDisplay,
      over_number:         currentOverNumber,
      legal_balls_in_over: legalBallsInOver,
      runs_off_bat,
      extra_type,
      is_wicket,
      wicket_type,
      wide_runs,
      bye_runs,
      leg_bye_runs,
      striker_name:        strikerName,
      bowler_name:         bowlerName,
      fielder_name:        fielderName,
      non_striker_name:    nonStrikerName,
      team_score_after:    newTeamScore,
      team_wickets_after:  newWickets,
      striker_runs_after:  strikerRunsAfter,
      striker_balls_after: strikerBallsAfter,
      is_boundary:         runs_off_bat === 4,
      is_six:              runs_off_bat === 6,
      innings_number:      innings.innings_number,
    });

    const finalCommentary = customCommentary || autoCommentary;
    const commentaryType  = engine.classifyCommentaryType({ is_wicket, runs_off_bat, extra_type });

    // ── Insert delivery ───────────────────────────────────────
    const deliveryRes = await client.query(`
      INSERT INTO deliveries (
        innings_id, over_id, over_number, ball_in_over, display_ball,
        striker_id, non_striker_id, bowler_id,
        is_legal_ball, runs_off_bat, extras_total, extra_type,
        wide_runs, no_ball_runs, bye_runs, leg_bye_runs,
        total_runs, is_wicket, wicket_type,
        dismissed_player_id, fielder_id, second_fielder_id,
        is_boundary, is_six, commentary,
        team_score_after, team_wickets_after, striker_runs_after
      ) VALUES (
        $1,$2,$3,$4,$5,
        $6,$7,$8,
        $9,$10,$11,$12,
        $13,$14,$15,$16,
        $17,$18,$19,
        $20,$21,$22,
        $23,$24,$25,
        $26,$27,$28
      ) RETURNING *
    `, [
      innings_id, currentOver.id, currentOverNumber, legalBallsInOver, ballDisplay,
      striker_id, non_striker_id, bowler_id,
      is_legal_ball, runs_off_bat, extras_total, extra_type,
      wide_runs, no_ball_runs, bye_runs, leg_bye_runs,
      total_runs, is_wicket, wicket_type,
      dismissed_player_id, fielder_id, second_fielder_id,
      runs_off_bat === 4, runs_off_bat === 6, finalCommentary,
      newTeamScore, newWickets, strikerRunsAfter
    ]);

    const delivery = deliveryRes.rows[0];

    // ── Update batter stats ───────────────────────────────────
    // BUG FIX A/C: Use fully parameterised queries, compute strike_rate in JS
    if (extra_type !== 'wide') {
      // Wide = no balls faced, no bat credit
      const ballsAdd = (is_legal_ball || extra_type === 'no_ball') ? 1 : 0;
      const newBalls = strikerBallsBefore + ballsAdd;
      const newSR    = newBalls > 0 ? parseFloat(((strikerRunsAfter / newBalls) * 100).toFixed(2)) : 0;

      const updateParts = [];
      const updateVals  = [];
      let pIdx = 1;

      if (ballsAdd > 0) {
        updateParts.push(`balls_faced = balls_faced + $${pIdx++}`);
        updateVals.push(ballsAdd);
      }
      if (runsForBatter > 0) {
        updateParts.push(`runs = runs + $${pIdx++}`);
        updateVals.push(runsForBatter);
        if (runs_off_bat === 4) { updateParts.push(`fours = fours + $${pIdx++}`); updateVals.push(1); }
        if (runs_off_bat === 6) { updateParts.push(`sixes = sixes + $${pIdx++}`); updateVals.push(1); }
      }
      // Always update strike_rate if balls faced changed
      if (ballsAdd > 0 || runsForBatter > 0) {
        updateParts.push(`strike_rate = $${pIdx++}`);
        updateVals.push(newSR);
      }

      if (updateParts.length > 0) {
        updateVals.push(innings_id, striker_id);
        await client.query(
          `UPDATE batter_stats SET ${updateParts.join(', ')} WHERE innings_id = $${pIdx++} AND player_id = $${pIdx++}`,
          updateVals
        );
      }
    }

    // ── Handle dismissal ──────────────────────────────────────
    if (is_wicket && dismissed_player_id) {
      const dismissedByBowler = ['bowled','caught','lbw','hit_wicket','stumped'].includes(wicket_type) ? bowler_id : null;
      await client.query(
        `UPDATE batter_stats SET status = 'out', dismissal_type = $1,
          dismissed_by_id = $2, fielder_id = $3, out_at_score = $4
         WHERE innings_id = $5 AND player_id = $6`,
        [wicket_type, dismissedByBowler, fielder_id || null, newTeamScore, innings_id, dismissed_player_id]
      );
      // Fall of wickets
      await client.query(
        `INSERT INTO fall_of_wickets (innings_id, wicket_number, player_id, score, overs, dismissal_type, delivery_id)
         VALUES ($1,$2,$3,$4,$5,$6,$7)`,
        [innings_id, newWickets, dismissed_player_id, newTeamScore, engine.formatOvers(newLegalBalls), wicket_type, delivery.id]
      );
    }

    // ── Update bowler stats ───────────────────────────────────
    // BUG FIX A: Use parameterised queries, compute overs_bowled in JS
    {
      const bowlerStatsRes = await client.query(
        'SELECT balls_bowled, runs_conceded FROM bowler_stats WHERE innings_id = $1 AND player_id = $2',
        [innings_id, bowler_id]
      );
      const bwRow = bowlerStatsRes.rows[0];
      if (bwRow) {
        const newBalls = (bwRow.balls_bowled || 0) + (is_legal_ball ? 1 : 0);
        const runsAdd  = (extra_type === 'bye' || extra_type === 'leg_bye') ? 0 : total_runs;
        const newRuns  = (bwRow.runs_conceded || 0) + runsAdd;
        const newOvers = engine.formatOvers(newBalls);
        const newEco   = newBalls > 0 ? parseFloat((newRuns / newBalls * 6).toFixed(2)) : 0;

        const bwParts = []; const bwVals = []; let bwIdx = 1;
        if (is_legal_ball) {
          bwParts.push(`balls_bowled = balls_bowled + $${bwIdx++}`); bwVals.push(1);
          if (runs_off_bat === 0 && !is_wicket && extra_type !== 'wide' && extra_type !== 'no_ball') {
            bwParts.push(`dot_balls = dot_balls + $${bwIdx++}`); bwVals.push(1);
          }
          if (runs_off_bat === 4) { bwParts.push(`fours_conceded = fours_conceded + $${bwIdx++}`); bwVals.push(1); }
          if (runs_off_bat === 6) { bwParts.push(`sixes_conceded = sixes_conceded + $${bwIdx++}`); bwVals.push(1); }
        }
        // Wicket credit (not for run-outs and other non-bowling dismissals)
        if (is_wicket && !['run_out','retired_out','retired_hurt','timed_out','obstructing_field'].includes(wicket_type)) {
          bwParts.push(`wickets = wickets + $${bwIdx++}`); bwVals.push(1);
        }
        if (extra_type === 'wide')    { bwParts.push(`wides = wides + $${bwIdx++}`);       bwVals.push(1); }
        if (extra_type === 'no_ball') { bwParts.push(`no_balls = no_balls + $${bwIdx++}`); bwVals.push(1); }
        if (runsAdd > 0) { bwParts.push(`runs_conceded = runs_conceded + $${bwIdx++}`); bwVals.push(runsAdd); }

        // Always update computed fields
        bwParts.push(`overs_bowled = $${bwIdx++}`); bwVals.push(newOvers);
        bwParts.push(`economy = $${bwIdx++}`);      bwVals.push(newEco);

        bwVals.push(innings_id, bowler_id);
        await client.query(
          `UPDATE bowler_stats SET ${bwParts.join(', ')} WHERE innings_id = $${bwIdx++} AND player_id = $${bwIdx++}`,
          bwVals
        );
      } else {
        console.warn(`bowler_stats row not found for innings=${innings_id} player=${bowler_id} — inserting`);
        await client.query(
          `INSERT INTO bowler_stats (innings_id, player_id, team_id, balls_bowled, runs_conceded)
           SELECT $1, $2, bowling_team_id, $3, $4 FROM innings WHERE id = $1 ON CONFLICT DO NOTHING`,
          [innings_id, bowler_id, is_legal_ball ? 1 : 0, (extra_type === 'bye' || extra_type === 'leg_bye') ? 0 : total_runs]
        );
      }
    }

    // ── Update over stats ─────────────────────────────────────
    const overRunsForBowler = (extra_type === 'bye' || extra_type === 'leg_bye') ? 0 : total_runs;
    await client.query(`
      UPDATE overs SET
        total_runs  = total_runs  + $1,
        legal_balls = legal_balls + $2,
        wickets     = wickets     + $3,
        wides       = wides       + $4,
        no_balls    = no_balls    + $5,
        byes        = byes        + $6,
        leg_byes    = leg_byes    + $7
      WHERE id = $8
    `, [
      overRunsForBowler,
      is_legal_ball ? 1 : 0,
      is_wicket     ? 1 : 0,
      extra_type === 'wide'    ? 1 : 0,
      extra_type === 'no_ball' ? 1 : 0,
      bye_runs, leg_bye_runs,
      currentOver.id
    ]);

    // ── Strike rotation ───────────────────────────────────────
    const isEndOfOver = is_legal_ball && (newLegalBalls % 6 === 0);
    const shouldRotate = rotate_strike_override !== null
      ? rotate_strike_override
      : engine.shouldRotateStrike({ runs_off_bat, extra_type, is_wicket, wicket_type, bye_runs, leg_bye_runs }, isEndOfOver);

    let newStriker    = striker_id;
    let newNonStriker = non_striker_id;

    if (is_wicket && dismissed_player_id === striker_id) {
      newStriker = null;
    } else if (is_wicket && dismissed_player_id === non_striker_id) {
      newNonStriker = null;
    } else if (shouldRotate) {
      [newStriker, newNonStriker] = [non_striker_id, striker_id];
    }

    // ── Over complete / maiden check ──────────────────────────
    let overComplete = isEndOfOver;
    let isMaiden = false;
    if (overComplete) {
      await client.query('UPDATE overs SET is_complete = true WHERE id = $1', [currentOver.id]);
      const overDeliveriesRes = await client.query(
        'SELECT * FROM deliveries WHERE over_id = $1', [currentOver.id]
      );
      isMaiden = engine.checkMaiden(overDeliveriesRes.rows);
      if (isMaiden) {
        await client.query('UPDATE overs SET is_maiden = true WHERE id = $1', [currentOver.id]);
        await client.query(
          'UPDATE bowler_stats SET maidens = maidens + 1 WHERE innings_id = $1 AND player_id = $2',
          [innings_id, bowler_id]
        );
      }
    }

    // ── Update innings totals (including live chase equation) ──
    const newCRR = engine.calculateCRR(newTeamScore, newLegalBalls);
    const ballsRemaining = (innings.overs_per_innings * 6) - newLegalBalls;
    const newRRR = innings.target ? engine.calculateRRR(innings.target, newTeamScore, ballsRemaining) : null;

    // Chase equation fields — only relevant in 2nd innings with a target
    const runsRequired = innings.target ? Math.max(0, innings.target - newTeamScore) : null;
    const wicketsInHand = innings.target ? (10 - newWickets) : null;
    // chase_status: won if target reached, lost if all out or overs done before target
    let chaseStatus = 'not_applicable';
    if (innings.target) {
      if (newTeamScore >= innings.target) chaseStatus = 'won';
      else if (newWickets >= 10 || ballsRemaining <= 0) chaseStatus = 'lost';
      else chaseStatus = 'in_progress';
    }

    await client.query(`
      UPDATE innings SET
        total_runs              = $1,
        total_wickets           = $2,
        total_balls             = $3,
        total_overs             = $4,
        extras_total            = extras_total     + $5,
        extras_wides            = extras_wides     + $6,
        extras_no_balls         = extras_no_balls  + $7,
        extras_byes             = extras_byes      + $8,
        extras_leg_byes         = extras_leg_byes  + $9,
        current_run_rate        = $10,
        required_run_rate       = $11,
        current_striker_id      = $12,
        current_non_striker_id  = $13,
        current_bowler_id       = $14,
        runs_required           = $16,
        balls_remaining         = $17,
        wickets_in_hand         = $18,
        chase_status            = $19
      WHERE id = $15
    `, [
      newTeamScore, newWickets, newLegalBalls,
      engine.formatOvers(newLegalBalls),
      extras_total,
      extra_type === 'wide'    ? 1 : 0,
      extra_type === 'no_ball' ? 1 : 0,
      bye_runs, leg_bye_runs,
      newCRR, newRRR,
      newStriker, newNonStriker, bowler_id,
      innings_id,
      runsRequired, ballsRemaining > 0 ? ballsRemaining : 0,
      wicketsInHand, chaseStatus
    ]);

    // ── Insert delivery commentary (upsert — prevent duplicates if called twice) ──
    await client.query(
      `INSERT INTO commentary (match_id, innings_id, delivery_id, over_number, ball_number, commentary_type, text)
       VALUES ($1,$2,$3,$4,$5,$6,$7)
       ON CONFLICT (delivery_id, commentary_type) WHERE delivery_id IS NOT NULL
       DO UPDATE SET text = EXCLUDED.text`,
      [
        innings.match_id, innings_id, delivery.id,
        currentOverNumber, legalBallsInOver + (is_legal_ball ? 1 : 0),
        commentaryType,
        finalCommentary
      ]
    );

    // ── Milestone commentary ─────────────────────────────────
    const milestoneType = engine._milestone(strikerRunsAfter, runsForBatter, extra_type, strikerName);
    if (milestoneType) {
      const milestoneText = engine.generateMilestoneCommentary({
        striker_name: strikerName,
        runs: strikerRunsAfter,
        balls: strikerBallsAfter,
        milestone_type: milestoneType
      });
      await client.query(
        `INSERT INTO commentary (match_id, innings_id, delivery_id, over_number, ball_number, commentary_type, text)
         VALUES ($1,$2,$3,$4,$5,'milestone',$6)
         ON CONFLICT (delivery_id, commentary_type) WHERE delivery_id IS NOT NULL DO UPDATE SET text = EXCLUDED.text`,
        [innings.match_id, innings_id, delivery.id, currentOverNumber, legalBallsInOver + (is_legal_ball ? 1 : 0), milestoneText]
      );
    }

    // ── Over-end commentary ───────────────────────────────────
    if (overComplete) {
      const updatedOver = await client.query('SELECT * FROM overs WHERE id = $1', [currentOver.id]);
      const ov = updatedOver.rows[0];
      const overEndText = engine.generateOverCompleteCommentary({
        over_number:   currentOverNumber,
        bowler_name:   bowlerName,
        over_runs:     ov.total_runs,
        over_wickets:  ov.wickets,
        is_maiden:     isMaiden,
        team_score:    newTeamScore,
        team_wickets:  newWickets
      });
      await client.query(
        `INSERT INTO commentary (match_id, innings_id, over_number, ball_number, commentary_type, text)
         VALUES ($1,$2,$3,6,'admin',$4)`,
        [innings.match_id, innings_id, currentOverNumber, overEndText]
      );
    }

    // ── Innings end check ─────────────────────────────────────
    const inningsEndCheck = engine.shouldEndInnings(
      { total_wickets: newWickets, total_balls: newLegalBalls, target: innings.target, total_runs: newTeamScore, declared: false },
      innings.overs_per_innings
    );

    if (inningsEndCheck.end) {
      const inningsStatus = inningsEndCheck.reason === 'declared' ? 'declared' : 'completed';
      await client.query(
        `UPDATE innings SET status = $1, all_out = $2 WHERE id = $3`,
        [inningsStatus, inningsEndCheck.reason === 'all_out', innings_id]
      );
      // Innings-end commentary
      const inningsEndText = engine.generateInningsEndCommentary({
        reason:            inningsEndCheck.reason,
        total_runs:        newTeamScore,
        total_wickets:     newWickets,
        total_overs:       engine.formatOvers(newLegalBalls),
        batting_team_name: innings.batting_team_name || 'Team',
        target:            innings.target ? innings.target : null
      });
      await client.query(
        `INSERT INTO commentary (match_id, innings_id, over_number, ball_number, commentary_type, text)
         VALUES ($1,$2,$3,$4,'innings_end',$5)`,
        [innings.match_id, innings_id, currentOverNumber, legalBallsInOver + (is_legal_ball ? 1 : 0), inningsEndText]
      );
    }

    // ── COMMIT ────────────────────────────────────────────────
    await client.query('COMMIT');

    // ── Broadcast real-time update ────────────────────────────
    global.broadcastMatch(innings.match_id, {
      type:         'score_update',
      matchId:      innings.match_id,
      innings_id,
      delivery,
      commentary:   finalCommentary,
      score:        { runs: newTeamScore, wickets: newWickets, overs: engine.formatOvers(newLegalBalls) },
      crr:          newCRR,
      rrr:          newRRR,
      striker:      newStriker,
      nonStriker:   newNonStriker,
      bowler:       bowler_id,
      isWicket:     is_wicket,
      isBoundary:   runs_off_bat === 4,
      isSix:        runs_off_bat === 6,
      overComplete,
      isMaiden,
      inningsEnd:   inningsEndCheck.end ? inningsEndCheck : null,
      milestone:    milestoneType,
      timestamp:    new Date().toISOString()
    });

    // Wicket notification
    if (is_wicket) {
      global.broadcastMatch(innings.match_id, {
        type:              'notification',
        notification_type: 'wicket',
        title:             'WICKET!',
        body:              `${strikerName} is out! ${wicket_type?.replace(/_/g, ' ') || ''}`,
        matchId:           innings.match_id
      });
    }

    res.json({
      success:       true,
      delivery,
      commentary:    finalCommentary,
      score:         { runs: newTeamScore, wickets: newWickets, overs: engine.formatOvers(newLegalBalls) },
      overComplete,
      isMaiden,
      needsNewBatter: is_wicket && newWickets < 10,
      inningsEnd:    inningsEndCheck.end ? inningsEndCheck : null,
      rotateStrike:  shouldRotate,
      newStriker,
      newNonStriker,
      milestone:     milestoneType
    });

  } catch (e) {
    await client.query('ROLLBACK');
    console.error('Scoring delivery error:', e.message, e.stack);
    // Always return 400 with readable message — no silent failures
    res.status(400).json({ error: e.message });
  } finally {
    client.release();
  }
});

// ─────────────────────────────────────────────────────────────
// POST /api/scoring/undo — Undo last delivery
// ─────────────────────────────────────────────────────────────
router.post('/undo', authenticate, requireAdmin, async (req, res) => {
  const { innings_id } = req.body;
  const client = await global.db.connect();
  try {
    await client.query('BEGIN');

    const lastDelivery = await client.query(
      `SELECT * FROM deliveries WHERE innings_id = $1 ORDER BY created_at DESC LIMIT 1`,
      [innings_id]
    );
    if (!lastDelivery.rows[0]) {
      await client.query('ROLLBACK');
      return res.status(400).json({ error: 'No deliveries to undo' });
    }
    const d = lastDelivery.rows[0];
    const isLegal = d.is_legal_ball;

    // Reverse innings totals
    await client.query(`
      UPDATE innings SET
        total_runs      = GREATEST(0, total_runs      - $1),
        total_wickets   = GREATEST(0, total_wickets   - $2),
        total_balls     = GREATEST(0, total_balls     - $3),
        extras_total    = GREATEST(0, extras_total    - $4),
        extras_wides    = GREATEST(0, extras_wides    - $5),
        extras_no_balls = GREATEST(0, extras_no_balls - $6),
        extras_byes     = GREATEST(0, extras_byes     - $7),
        extras_leg_byes = GREATEST(0, extras_leg_byes - $8)
      WHERE id = $9
    `, [
      d.total_runs, d.is_wicket ? 1 : 0, isLegal ? 1 : 0,
      d.extras_total,
      d.extra_type === 'wide'    ? 1 : 0,
      d.extra_type === 'no_ball' ? 1 : 0,
      d.bye_runs || 0,
      d.leg_bye_runs || 0,
      innings_id
    ]);

    // Reverse batter stats
    if (d.extra_type !== 'wide') {
      const runsForBatter = (d.extra_type === 'bye' || d.extra_type === 'leg_bye') ? 0 : (d.runs_off_bat || 0);
      const ballsAdd = (isLegal || d.extra_type === 'no_ball') ? 1 : 0;

      const revParts = []; const revVals = []; let ri = 1;
      if (ballsAdd > 0) { revParts.push(`balls_faced = GREATEST(0, balls_faced - $${ri++})`); revVals.push(ballsAdd); }
      if (runsForBatter > 0) {
        revParts.push(`runs = GREATEST(0, runs - $${ri++})`); revVals.push(runsForBatter);
        if (d.runs_off_bat === 4) { revParts.push(`fours = GREATEST(0, fours - $${ri++})`); revVals.push(1); }
        if (d.runs_off_bat === 6) { revParts.push(`sixes = GREATEST(0, sixes - $${ri++})`); revVals.push(1); }
      }
      if (revParts.length > 0) {
        revVals.push(innings_id, d.striker_id);
        await client.query(
          `UPDATE batter_stats SET ${revParts.join(', ')} WHERE innings_id = $${ri++} AND player_id = $${ri++}`,
          revVals
        );
      }
    }

    // Undo dismissal
    if (d.is_wicket && d.dismissed_player_id) {
      await client.query(
        `UPDATE batter_stats SET status = 'batting', dismissal_type = NULL, dismissed_by_id = NULL, fielder_id = NULL, out_at_score = NULL WHERE innings_id = $1 AND player_id = $2`,
        [innings_id, d.dismissed_player_id]
      );
      await client.query(`DELETE FROM fall_of_wickets WHERE delivery_id = $1`, [d.id]);
    }

    // Reverse bowler stats
    if (d.bowler_id) {
      const runsForBowler = (d.extra_type === 'bye' || d.extra_type === 'leg_bye') ? 0 : (d.total_runs || 0);
      const bwRevParts = []; const bwRevVals = []; let bi = 1;
      if (isLegal) { bwRevParts.push(`balls_bowled = GREATEST(0, balls_bowled - $${bi++})`); bwRevVals.push(1); }
      if (runsForBowler > 0) { bwRevParts.push(`runs_conceded = GREATEST(0, runs_conceded - $${bi++})`); bwRevVals.push(runsForBowler); }
      if (d.is_wicket) { bwRevParts.push(`wickets = GREATEST(0, wickets - $${bi++})`); bwRevVals.push(1); }
      if (d.extra_type === 'wide')    { bwRevParts.push(`wides = GREATEST(0, wides - $${bi++})`);       bwRevVals.push(1); }
      if (d.extra_type === 'no_ball') { bwRevParts.push(`no_balls = GREATEST(0, no_balls - $${bi++})`); bwRevVals.push(1); }
      if (bwRevParts.length > 0) {
        bwRevVals.push(innings_id, d.bowler_id);
        await client.query(
          `UPDATE bowler_stats SET ${bwRevParts.join(', ')} WHERE innings_id = $${bi++} AND player_id = $${bi++}`,
          bwRevVals
        );
      }
    }

    // Delete commentary
    await client.query(`DELETE FROM commentary WHERE delivery_id = $1`, [d.id]);
    // Delete delivery
    await client.query(`DELETE FROM deliveries WHERE id = $1`, [d.id]);

    // Recalculate innings
    const updatedInn = await client.query('SELECT * FROM innings WHERE id = $1', [innings_id]);
    const inn = updatedInn.rows[0];
    const newCRR = engine.calculateCRR(inn.total_runs, inn.total_balls);
    await client.query(
      `UPDATE innings SET current_run_rate = $1, total_overs = $2, status = 'in_progress' WHERE id = $3`,
      [newCRR, engine.formatOvers(inn.total_balls), innings_id]
    );

    await client.query('COMMIT');

    global.broadcastMatch(inn.match_id, {
      type: 'delivery_undone',
      matchId: inn.match_id,
      innings_id,
      score: { runs: inn.total_runs, wickets: inn.total_wickets, overs: engine.formatOvers(inn.total_balls) }
    });

    res.json({ success: true, undoneDelivery: d });
  } catch (e) {
    await client.query('ROLLBACK');
    console.error('Undo error:', e.message);
    res.status(500).json({ error: e.message });
  } finally {
    client.release();
  }
});

// ─────────────────────────────────────────────────────────────
// POST /api/scoring/set-batters
// ─────────────────────────────────────────────────────────────
router.post('/set-batters', authenticate, requireAdmin, async (req, res) => {
  const { innings_id, striker_id, non_striker_id } = req.body;
  if (!innings_id) return res.status(400).json({ error: 'innings_id required' });
  if (!striker_id) return res.status(400).json({ error: 'striker_id required' });
  try {
    if (striker_id) {
      await global.db.query(
        `UPDATE batter_stats SET status = 'batting' WHERE innings_id = $1 AND player_id = $2`,
        [innings_id, striker_id]
      );
    }
    if (non_striker_id) {
      await global.db.query(
        `UPDATE batter_stats SET status = 'batting' WHERE innings_id = $1 AND player_id = $2`,
        [innings_id, non_striker_id]
      );
    }
    await global.db.query(
      `UPDATE innings SET current_striker_id = $1, current_non_striker_id = $2 WHERE id = $3`,
      [striker_id, non_striker_id || null, innings_id]
    );
    res.json({ success: true });
  } catch (e) {
    console.error('set-batters error:', e.message);
    res.status(500).json({ error: e.message });
  }
});

// ─────────────────────────────────────────────────────────────
// POST /api/scoring/set-bowler
// ─────────────────────────────────────────────────────────────
router.post('/set-bowler', authenticate, requireAdmin, async (req, res) => {
  const { innings_id, bowler_id } = req.body;
  if (!innings_id) return res.status(400).json({ error: 'innings_id required' });
  if (!bowler_id)  return res.status(400).json({ error: 'bowler_id required' });
  try {
    await global.db.query(
      `UPDATE innings SET current_bowler_id = $1 WHERE id = $2`,
      [bowler_id, innings_id]
    );
    const inn = await global.db.query('SELECT bowling_team_id FROM innings WHERE id = $1', [innings_id]);
    if (inn.rows[0]) {
      await global.db.query(
        `INSERT INTO bowler_stats (innings_id, player_id, team_id) VALUES ($1,$2,$3) ON CONFLICT DO NOTHING`,
        [innings_id, bowler_id, inn.rows[0].bowling_team_id]
      );
    }
    res.json({ success: true });
  } catch (e) {
    console.error('set-bowler error:', e.message);
    res.status(500).json({ error: e.message });
  }
});

// ─────────────────────────────────────────────────────────────
// POST /api/scoring/end-innings
// ─────────────────────────────────────────────────────────────
router.post('/end-innings', authenticate, requireAdmin, async (req, res) => {
  const { innings_id, reason = 'declared' } = req.body;
  if (!innings_id) return res.status(400).json({ error: 'innings_id required' });
  try {
    const inn = await global.db.query('SELECT * FROM innings WHERE id = $1', [innings_id]);
    if (!inn.rows[0]) return res.status(404).json({ error: 'Innings not found' });
    const status = reason === 'declared' ? 'declared' : 'completed';
    await global.db.query(
      `UPDATE innings SET status = $1, declared = $2 WHERE id = $3`,
      [status, reason === 'declared', innings_id]
    );
    global.broadcastMatch(inn.rows[0].match_id, { type: 'innings_end', matchId: inn.rows[0].match_id, innings_id, reason });
    res.json({ success: true });
  } catch (e) {
    console.error('end-innings error:', e.message);
    res.status(500).json({ error: e.message });
  }
});

module.exports = router;
