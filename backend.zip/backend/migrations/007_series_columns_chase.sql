-- ============================================================
-- MIGRATION 007: Add missing series columns + chase fields
-- ============================================================

-- Feature 2: Add missing columns to series table
ALTER TABLE series ADD COLUMN IF NOT EXISTS description TEXT;
ALTER TABLE series ADD COLUMN IF NOT EXISTS season VARCHAR(20);
ALTER TABLE series ADD COLUMN IF NOT EXISTS status VARCHAR(20) DEFAULT 'upcoming'
  CHECK (status IN ('upcoming', 'live', 'completed', 'cancelled'));

-- Feature 1: Add computed chase fields to innings table
-- (runs_required and balls_remaining stored for fast API access)
ALTER TABLE innings ADD COLUMN IF NOT EXISTS runs_required INTEGER;
ALTER TABLE innings ADD COLUMN IF NOT EXISTS balls_remaining INTEGER;
ALTER TABLE innings ADD COLUMN IF NOT EXISTS wickets_in_hand INTEGER;
ALTER TABLE innings ADD COLUMN IF NOT EXISTS chase_status VARCHAR(30) DEFAULT 'in_progress'
  CHECK (chase_status IN ('in_progress', 'won', 'lost', 'tied', 'not_applicable'));

-- Index for series status lookups
CREATE INDEX IF NOT EXISTS idx_series_status ON series(status);
CREATE INDEX IF NOT EXISTS idx_series_active ON series(is_active);
