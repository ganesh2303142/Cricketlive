-- ============================================================
-- MIGRATION 003: OTP/Password Reset, Squad fixes, Soft deletes
-- ============================================================

-- Add phone number to users
ALTER TABLE users ADD COLUMN IF NOT EXISTS phone VARCHAR(20);
ALTER TABLE users ADD COLUMN IF NOT EXISTS deleted_at TIMESTAMPTZ;

-- OTP / Password Reset table
CREATE TABLE IF NOT EXISTS otp_verifications (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  identifier VARCHAR(255) NOT NULL,         -- email or phone
  identifier_type VARCHAR(10) NOT NULL CHECK (identifier_type IN ('email', 'phone')),
  otp_hash VARCHAR(255) NOT NULL,           -- bcrypt hashed OTP
  purpose VARCHAR(30) NOT NULL DEFAULT 'password_reset' CHECK (purpose IN ('password_reset', 'login_verify')),
  attempts INTEGER DEFAULT 0,
  max_attempts INTEGER DEFAULT 5,
  expires_at TIMESTAMPTZ NOT NULL,
  used_at TIMESTAMPTZ,
  ip_address VARCHAR(45),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Rate limiting table for OTP requests
CREATE TABLE IF NOT EXISTS otp_rate_limits (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  identifier VARCHAR(255) NOT NULL,
  window_start TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  request_count INTEGER DEFAULT 1,
  blocked_until TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(identifier, window_start)
);

-- Password reset audit log
CREATE TABLE IF NOT EXISTS security_audit_log (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES users(id),
  event_type VARCHAR(50) NOT NULL,          -- password_reset, login_fail, otp_sent, etc
  identifier VARCHAR(255),
  ip_address VARCHAR(45),
  user_agent TEXT,
  success BOOLEAN DEFAULT false,
  metadata JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Soft delete for teams
ALTER TABLE teams ADD COLUMN IF NOT EXISTS deleted_at TIMESTAMPTZ;

-- Soft delete for players
ALTER TABLE players ADD COLUMN IF NOT EXISTS deleted_at TIMESTAMPTZ;

-- Soft delete for matches
ALTER TABLE matches ADD COLUMN IF NOT EXISTS deleted_at TIMESTAMPTZ;

-- Add squad_status to squads for better management
ALTER TABLE squads ADD COLUMN IF NOT EXISTS squad_status VARCHAR(20) DEFAULT 'confirmed' CHECK (squad_status IN ('confirmed', 'tentative', 'withdrawn'));

-- Add match setup checklist flags to matches
ALTER TABLE matches ADD COLUMN IF NOT EXISTS squads_assigned BOOLEAN DEFAULT false;
ALTER TABLE matches ADD COLUMN IF NOT EXISTS setup_complete BOOLEAN DEFAULT false;

-- Update squads table to allow team_a + team_b tracking
ALTER TABLE squads ADD COLUMN IF NOT EXISTS is_substitute BOOLEAN DEFAULT false;

-- Indexes for OTP
CREATE INDEX IF NOT EXISTS idx_otp_identifier ON otp_verifications(identifier);
CREATE INDEX IF NOT EXISTS idx_otp_expires ON otp_verifications(expires_at);
CREATE INDEX IF NOT EXISTS idx_audit_user ON security_audit_log(user_id);
CREATE INDEX IF NOT EXISTS idx_audit_event ON security_audit_log(event_type);
CREATE INDEX IF NOT EXISTS idx_teams_deleted ON teams(deleted_at);
CREATE INDEX IF NOT EXISTS idx_players_deleted ON players(deleted_at);
CREATE INDEX IF NOT EXISTS idx_matches_deleted ON matches(deleted_at);

-- Update existing seed users to have phone (optional demo)
UPDATE users SET phone = NULL WHERE phone IS NULL;
