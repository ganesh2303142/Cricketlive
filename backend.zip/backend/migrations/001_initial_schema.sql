-- Cricket Live Scorecard - Complete Database Schema
-- Run in order

-- ============================================================
-- USERS & AUTH
-- ============================================================

CREATE TABLE IF NOT EXISTS users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email VARCHAR(255) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  name VARCHAR(255) NOT NULL,
  role VARCHAR(20) NOT NULL DEFAULT 'user' CHECK (role IN ('user', 'admin', 'scorer')),
  avatar_url TEXT,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- TEAMS
-- ============================================================

CREATE TABLE IF NOT EXISTS teams (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name VARCHAR(255) NOT NULL,
  short_name VARCHAR(10) NOT NULL,
  logo_url TEXT,
  country VARCHAR(100),
  city VARCHAR(100),
  color_primary VARCHAR(7) DEFAULT '#1a9c3e',
  color_secondary VARCHAR(7) DEFAULT '#ffffff',
  created_by UUID REFERENCES users(id),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- PLAYERS
-- ============================================================

CREATE TABLE IF NOT EXISTS players (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name VARCHAR(255) NOT NULL,
  short_name VARCHAR(50),
  date_of_birth DATE,
  nationality VARCHAR(100),
  batting_style VARCHAR(50) CHECK (batting_style IN ('Right-hand bat', 'Left-hand bat')),
  bowling_style VARCHAR(100),
  role VARCHAR(50) CHECK (role IN ('Batsman', 'Bowler', 'All-rounder', 'Wicket-keeper')),
  jersey_number INTEGER,
  photo_url TEXT,
  team_id UUID REFERENCES teams(id),
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- VENUES
-- ============================================================

CREATE TABLE IF NOT EXISTS venues (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name VARCHAR(255) NOT NULL,
  city VARCHAR(100),
  country VARCHAR(100),
  capacity INTEGER,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- SERIES / TOURNAMENTS
-- ============================================================

CREATE TABLE IF NOT EXISTS series (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name VARCHAR(255) NOT NULL,
  short_name VARCHAR(50),
  series_type VARCHAR(50) CHECK (series_type IN ('International', 'Domestic', 'IPL', 'T20 League', 'World Cup', 'Custom')),
  start_date DATE,
  end_date DATE,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- MATCHES
-- ============================================================

CREATE TABLE IF NOT EXISTS matches (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  series_id UUID REFERENCES series(id),
  match_number INTEGER,
  match_type VARCHAR(20) NOT NULL CHECK (match_type IN ('T20', 'ODI', 'Test', 'T10', 'Custom')),
  overs_per_innings INTEGER NOT NULL DEFAULT 20,
  venue_id UUID REFERENCES venues(id),
  team_a_id UUID NOT NULL REFERENCES teams(id),
  team_b_id UUID NOT NULL REFERENCES teams(id),
  scheduled_at TIMESTAMPTZ NOT NULL,
  status VARCHAR(30) NOT NULL DEFAULT 'upcoming' CHECK (status IN ('upcoming', 'toss', 'live', 'innings_break', 'completed', 'abandoned', 'rain_delay')),
  toss_winner_id UUID REFERENCES teams(id),
  toss_decision VARCHAR(10) CHECK (toss_decision IN ('bat', 'field')),
  batting_first_team_id UUID REFERENCES teams(id),
  current_innings INTEGER DEFAULT 1,
  result_text TEXT,
  winner_id UUID REFERENCES teams(id),
  man_of_match_id UUID REFERENCES players(id),
  is_dls BOOLEAN DEFAULT false,
  dls_target INTEGER,
  notes TEXT,
  created_by UUID REFERENCES users(id),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- SQUADS (team players for a match)
-- ============================================================

CREATE TABLE IF NOT EXISTS squads (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  match_id UUID NOT NULL REFERENCES matches(id) ON DELETE CASCADE,
  team_id UUID NOT NULL REFERENCES teams(id),
  player_id UUID NOT NULL REFERENCES players(id),
  is_playing_xi BOOLEAN DEFAULT true,
  is_captain BOOLEAN DEFAULT false,
  is_wicketkeeper BOOLEAN DEFAULT false,
  is_impact_player BOOLEAN DEFAULT false,
  batting_order INTEGER,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(match_id, player_id)
);

-- ============================================================
-- INNINGS
-- ============================================================

CREATE TABLE IF NOT EXISTS innings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  match_id UUID NOT NULL REFERENCES matches(id) ON DELETE CASCADE,
  innings_number INTEGER NOT NULL CHECK (innings_number IN (1, 2, 3, 4)),
  batting_team_id UUID NOT NULL REFERENCES teams(id),
  bowling_team_id UUID NOT NULL REFERENCES teams(id),
  target INTEGER,
  total_runs INTEGER DEFAULT 0,
  total_wickets INTEGER DEFAULT 0,
  total_overs DECIMAL(5,1) DEFAULT 0,
  total_balls INTEGER DEFAULT 0,
  extras_total INTEGER DEFAULT 0,
  extras_wides INTEGER DEFAULT 0,
  extras_no_balls INTEGER DEFAULT 0,
  extras_byes INTEGER DEFAULT 0,
  extras_leg_byes INTEGER DEFAULT 0,
  extras_penalty INTEGER DEFAULT 0,
  current_run_rate DECIMAL(5,2) DEFAULT 0,
  required_run_rate DECIMAL(5,2),
  status VARCHAR(20) DEFAULT 'yet_to_start' CHECK (status IN ('yet_to_start', 'in_progress', 'completed', 'declared', 'forfeited')),
  declared BOOLEAN DEFAULT false,
  all_out BOOLEAN DEFAULT false,
  powerplay_score INTEGER DEFAULT 0,
  powerplay_wickets INTEGER DEFAULT 0,
  powerplay_overs INTEGER DEFAULT 6,
  current_striker_id UUID REFERENCES players(id),
  current_non_striker_id UUID REFERENCES players(id),
  current_bowler_id UUID REFERENCES players(id),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(match_id, innings_number)
);

-- ============================================================
-- OVERS
-- ============================================================

CREATE TABLE IF NOT EXISTS overs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  innings_id UUID NOT NULL REFERENCES innings(id) ON DELETE CASCADE,
  over_number INTEGER NOT NULL,
  bowler_id UUID NOT NULL REFERENCES players(id),
  total_runs INTEGER DEFAULT 0,
  legal_balls INTEGER DEFAULT 0,
  wickets INTEGER DEFAULT 0,
  wides INTEGER DEFAULT 0,
  no_balls INTEGER DEFAULT 0,
  byes INTEGER DEFAULT 0,
  leg_byes INTEGER DEFAULT 0,
  is_maiden BOOLEAN DEFAULT false,
  is_complete BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(innings_id, over_number)
);

-- ============================================================
-- DELIVERIES (core scoring record)
-- ============================================================

CREATE TABLE IF NOT EXISTS deliveries (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  innings_id UUID NOT NULL REFERENCES innings(id) ON DELETE CASCADE,
  over_id UUID NOT NULL REFERENCES overs(id) ON DELETE CASCADE,
  over_number INTEGER NOT NULL,
  ball_in_over INTEGER NOT NULL,
  display_ball VARCHAR(10) NOT NULL,
  striker_id UUID NOT NULL REFERENCES players(id),
  non_striker_id UUID NOT NULL REFERENCES players(id),
  bowler_id UUID NOT NULL REFERENCES players(id),
  is_legal_ball BOOLEAN NOT NULL DEFAULT true,
  runs_off_bat INTEGER NOT NULL DEFAULT 0,
  extras_total INTEGER NOT NULL DEFAULT 0,
  extra_type VARCHAR(20) CHECK (extra_type IN ('wide', 'no_ball', 'bye', 'leg_bye', 'penalty', NULL)),
  wide_runs INTEGER DEFAULT 0,
  no_ball_runs INTEGER DEFAULT 0,
  bye_runs INTEGER DEFAULT 0,
  leg_bye_runs INTEGER DEFAULT 0,
  penalty_runs INTEGER DEFAULT 0,
  total_runs INTEGER NOT NULL DEFAULT 0,
  is_wicket BOOLEAN DEFAULT false,
  wicket_type VARCHAR(30) CHECK (wicket_type IN ('bowled', 'caught', 'lbw', 'run_out', 'stumped', 'hit_wicket', 'retired_out', 'retired_hurt', 'timed_out', 'obstructing_field', 'handled_ball', NULL)),
  dismissed_player_id UUID REFERENCES players(id),
  fielder_id UUID REFERENCES players(id),
  second_fielder_id UUID REFERENCES players(id),
  is_boundary BOOLEAN DEFAULT false,
  is_six BOOLEAN DEFAULT false,
  commentary TEXT,
  events JSONB DEFAULT '[]',
  team_score_after INTEGER,
  team_wickets_after INTEGER,
  striker_runs_after INTEGER,
  timestamp TIMESTAMPTZ DEFAULT NOW(),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- BATTER STATS (per innings)
-- ============================================================

CREATE TABLE IF NOT EXISTS batter_stats (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  innings_id UUID NOT NULL REFERENCES innings(id) ON DELETE CASCADE,
  player_id UUID NOT NULL REFERENCES players(id),
  team_id UUID NOT NULL REFERENCES teams(id),
  batting_order INTEGER,
  runs INTEGER DEFAULT 0,
  balls_faced INTEGER DEFAULT 0,
  fours INTEGER DEFAULT 0,
  sixes INTEGER DEFAULT 0,
  strike_rate DECIMAL(6,2) DEFAULT 0,
  dismissal_type VARCHAR(30),
  dismissed_by_id UUID REFERENCES players(id),
  fielder_id UUID REFERENCES players(id),
  status VARCHAR(20) DEFAULT 'yet_to_bat' CHECK (status IN ('yet_to_bat', 'batting', 'out', 'retired_hurt', 'retired_out', 'not_out', 'dnb')),
  came_in_at_score INTEGER,
  came_in_at_over DECIMAL(5,1),
  out_at_score INTEGER,
  minutes_batted INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(innings_id, player_id)
);

-- ============================================================
-- BOWLER STATS (per innings)
-- ============================================================

CREATE TABLE IF NOT EXISTS bowler_stats (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  innings_id UUID NOT NULL REFERENCES innings(id) ON DELETE CASCADE,
  player_id UUID NOT NULL REFERENCES players(id),
  team_id UUID NOT NULL REFERENCES teams(id),
  overs_bowled DECIMAL(5,1) DEFAULT 0,
  balls_bowled INTEGER DEFAULT 0,
  maidens INTEGER DEFAULT 0,
  runs_conceded INTEGER DEFAULT 0,
  wickets INTEGER DEFAULT 0,
  economy DECIMAL(5,2) DEFAULT 0,
  wides INTEGER DEFAULT 0,
  no_balls INTEGER DEFAULT 0,
  dot_balls INTEGER DEFAULT 0,
  fours_conceded INTEGER DEFAULT 0,
  sixes_conceded INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(innings_id, player_id)
);

-- ============================================================
-- PARTNERSHIPS
-- ============================================================

CREATE TABLE IF NOT EXISTS partnerships (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  innings_id UUID NOT NULL REFERENCES innings(id) ON DELETE CASCADE,
  wicket_number INTEGER NOT NULL,
  batter1_id UUID NOT NULL REFERENCES players(id),
  batter2_id UUID NOT NULL REFERENCES players(id),
  runs INTEGER DEFAULT 0,
  balls INTEGER DEFAULT 0,
  batter1_runs INTEGER DEFAULT 0,
  batter2_runs INTEGER DEFAULT 0,
  start_score INTEGER DEFAULT 0,
  end_score INTEGER,
  is_unbroken BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- FALL OF WICKETS
-- ============================================================

CREATE TABLE IF NOT EXISTS fall_of_wickets (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  innings_id UUID NOT NULL REFERENCES innings(id) ON DELETE CASCADE,
  wicket_number INTEGER NOT NULL,
  player_id UUID NOT NULL REFERENCES players(id),
  score INTEGER NOT NULL,
  overs DECIMAL(5,1) NOT NULL,
  dismissal_type VARCHAR(30),
  delivery_id UUID REFERENCES deliveries(id),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- COMMENTARY
-- ============================================================

CREATE TABLE IF NOT EXISTS commentary (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  match_id UUID NOT NULL REFERENCES matches(id) ON DELETE CASCADE,
  innings_id UUID REFERENCES innings(id),
  delivery_id UUID REFERENCES deliveries(id),
  over_number INTEGER,
  ball_number INTEGER,
  commentary_type VARCHAR(20) DEFAULT 'regular' CHECK (commentary_type IN ('regular', 'wicket', 'boundary', 'six', 'milestone', 'review', 'injury', 'drinks', 'innings_end', 'match_end', 'admin')),
  text TEXT NOT NULL,
  timestamp TIMESTAMPTZ DEFAULT NOW(),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- NOTIFICATIONS
-- ============================================================

CREATE TABLE IF NOT EXISTS notifications (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  match_id UUID NOT NULL REFERENCES matches(id) ON DELETE CASCADE,
  notification_type VARCHAR(30) NOT NULL CHECK (notification_type IN ('match_start', 'toss', 'wicket', 'boundary', 'six', 'fifty', 'hundred', 'innings_break', 'match_result', 'rain_delay', 'review')),
  title VARCHAR(255) NOT NULL,
  body TEXT NOT NULL,
  data JSONB DEFAULT '{}',
  sent_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- INDEXES
-- ============================================================

CREATE INDEX IF NOT EXISTS idx_matches_status ON matches(status);
CREATE INDEX IF NOT EXISTS idx_matches_scheduled ON matches(scheduled_at);
CREATE INDEX IF NOT EXISTS idx_deliveries_innings ON deliveries(innings_id);
CREATE INDEX IF NOT EXISTS idx_deliveries_over ON deliveries(over_id);
CREATE INDEX IF NOT EXISTS idx_batter_stats_innings ON batter_stats(innings_id);
CREATE INDEX IF NOT EXISTS idx_bowler_stats_innings ON bowler_stats(innings_id);
CREATE INDEX IF NOT EXISTS idx_commentary_match ON commentary(match_id);
CREATE INDEX IF NOT EXISTS idx_commentary_innings ON commentary(innings_id);
CREATE INDEX IF NOT EXISTS idx_squads_match ON squads(match_id);
CREATE INDEX IF NOT EXISTS idx_notifications_match ON notifications(match_id);

-- ============================================================
-- TRIGGER: Update updated_at
-- ============================================================

CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS update_matches_updated_at ON matches;
CREATE TRIGGER update_matches_updated_at BEFORE UPDATE ON matches FOR EACH ROW EXECUTE FUNCTION update_updated_at();

DROP TRIGGER IF EXISTS update_innings_updated_at ON innings;
CREATE TRIGGER update_innings_updated_at BEFORE UPDATE ON innings FOR EACH ROW EXECUTE FUNCTION update_updated_at();

DROP TRIGGER IF EXISTS update_batter_stats_updated_at ON batter_stats;
CREATE TRIGGER update_batter_stats_updated_at BEFORE UPDATE ON batter_stats FOR EACH ROW EXECUTE FUNCTION update_updated_at();

DROP TRIGGER IF EXISTS update_bowler_stats_updated_at ON bowler_stats;
CREATE TRIGGER update_bowler_stats_updated_at BEFORE UPDATE ON bowler_stats FOR EACH ROW EXECUTE FUNCTION update_updated_at();
