-- Cricket Live Scorecard - Seed Data
-- Demo match: India vs Australia T20

-- Admin user (password: Admin@123) — email: ganeshsanjan78@gmail.com
INSERT INTO users (id, email, password_hash, name, role) VALUES
  ('00000000-0000-0000-0000-000000000001', 'ganeshsanjan78@gmail.com', '$2a$10$rQnv0DpXP4a0X4g.JvH8iuVeqS3Ynt.Xdce9JrKdJCRxI5UJf3km', 'Admin User', 'admin'),
  ('00000000-0000-0000-0000-000000000002', 'scorer@ganeshcricket.local', '$2a$10$rQnv0DpXP4a0X4g.JvH8iuVeqS3Ynt.Xdce9JrKdJCRxI5UJf3km', 'Live Scorer', 'scorer')
ON CONFLICT DO NOTHING;

-- Venues
INSERT INTO venues (id, name, city, country, capacity) VALUES
  ('v0000000-0000-0000-0000-000000000001', 'Wankhede Stadium', 'Mumbai', 'India', 33000),
  ('v0000000-0000-0000-0000-000000000002', 'Eden Gardens', 'Kolkata', 'India', 66000),
  ('v0000000-0000-0000-0000-000000000003', 'Melbourne Cricket Ground', 'Melbourne', 'Australia', 100024),
  ('v0000000-0000-0000-0000-000000000004', 'Lord''s Cricket Ground', 'London', 'England', 30000)
ON CONFLICT DO NOTHING;

-- Series
INSERT INTO series (id, name, short_name, series_type, start_date, end_date, is_active) VALUES
  ('s0000000-0000-0000-0000-000000000001', 'India vs Australia T20 Series 2025', 'IND vs AUS', 'International', '2025-01-15', '2025-01-25', true),
  ('s0000000-0000-0000-0000-000000000002', 'IPL 2025', 'IPL 2025', 'IPL', '2025-03-22', '2025-05-25', true)
ON CONFLICT DO NOTHING;

-- Teams
INSERT INTO teams (id, name, short_name, country, color_primary, color_secondary) VALUES
  ('t0000000-0000-0000-0000-000000000001', 'India', 'IND', 'India', '#1a9c3e', '#ff6a00'),
  ('t0000000-0000-0000-0000-000000000002', 'Australia', 'AUS', 'Australia', '#f4a300', '#006400'),
  ('t0000000-0000-0000-0000-000000000003', 'England', 'ENG', 'England', '#003399', '#cc0000'),
  ('t0000000-0000-0000-0000-000000000004', 'Mumbai Indians', 'MI', 'India', '#004c93', '#d4af37'),
  ('t0000000-0000-0000-0000-000000000005', 'Chennai Super Kings', 'CSK', 'India', '#ffff00', '#0048bb')
ON CONFLICT DO NOTHING;

-- Players - India
INSERT INTO players (id, name, short_name, nationality, batting_style, bowling_style, role, jersey_number, team_id) VALUES
  ('p0000001-0000-0000-0000-000000000001', 'Rohit Sharma', 'RG Sharma', 'Indian', 'Right-hand bat', 'Right-arm off break', 'Batsman', 45, 't0000000-0000-0000-0000-000000000001'),
  ('p0000001-0000-0000-0000-000000000002', 'Virat Kohli', 'V Kohli', 'Indian', 'Right-hand bat', 'Right-arm medium', 'Batsman', 18, 't0000000-0000-0000-0000-000000000001'),
  ('p0000001-0000-0000-0000-000000000003', 'Shubman Gill', 'S Gill', 'Indian', 'Right-hand bat', 'Right-arm off break', 'Batsman', 77, 't0000000-0000-0000-0000-000000000001'),
  ('p0000001-0000-0000-0000-000000000004', 'Suryakumar Yadav', 'SK Yadav', 'Indian', 'Right-hand bat', 'Right-arm medium', 'Batsman', 63, 't0000000-0000-0000-0000-000000000001'),
  ('p0000001-0000-0000-0000-000000000005', 'Hardik Pandya', 'H Pandya', 'Indian', 'Right-hand bat', 'Right-arm fast-medium', 'All-rounder', 228, 't0000000-0000-0000-0000-000000000001'),
  ('p0000001-0000-0000-0000-000000000006', 'Ravindra Jadeja', 'RA Jadeja', 'Indian', 'Left-hand bat', 'Slow left-arm orthodox', 'All-rounder', 8, 't0000000-0000-0000-0000-000000000001'),
  ('p0000001-0000-0000-0000-000000000007', 'KL Rahul', 'KL Rahul', 'Indian', 'Right-hand bat', 'Right-arm off break', 'Wicket-keeper', 1, 't0000000-0000-0000-0000-000000000001'),
  ('p0000001-0000-0000-0000-000000000008', 'Jasprit Bumrah', 'JJ Bumrah', 'Indian', 'Right-hand bat', 'Right-arm fast', 'Bowler', 93, 't0000000-0000-0000-0000-000000000001'),
  ('p0000001-0000-0000-0000-000000000009', 'Mohammed Shami', 'M Shami', 'Indian', 'Right-hand bat', 'Right-arm fast-medium', 'Bowler', 11, 't0000000-0000-0000-0000-000000000001'),
  ('p0000001-0000-0000-0000-000000000010', 'Arshdeep Singh', 'A Singh', 'Indian', 'Left-hand bat', 'Left-arm fast-medium', 'Bowler', 2, 't0000000-0000-0000-0000-000000000001'),
  ('p0000001-0000-0000-0000-000000000011', 'Axar Patel', 'AR Patel', 'Indian', 'Left-hand bat', 'Slow left-arm orthodox', 'All-rounder', 20, 't0000000-0000-0000-0000-000000000001')
ON CONFLICT DO NOTHING;

-- Players - Australia
INSERT INTO players (id, name, short_name, nationality, batting_style, bowling_style, role, jersey_number, team_id) VALUES
  ('p0000002-0000-0000-0000-000000000001', 'Pat Cummins', 'PJ Cummins', 'Australian', 'Right-hand bat', 'Right-arm fast', 'All-rounder', 30, 't0000000-0000-0000-0000-000000000002'),
  ('p0000002-0000-0000-0000-000000000002', 'David Warner', 'DA Warner', 'Australian', 'Left-hand bat', 'Right-arm off break', 'Batsman', 31, 't0000000-0000-0000-0000-000000000002'),
  ('p0000002-0000-0000-0000-000000000003', 'Travis Head', 'TM Head', 'Australian', 'Left-hand bat', 'Right-arm off break', 'Batsman', 62, 't0000000-0000-0000-0000-000000000002'),
  ('p0000002-0000-0000-0000-000000000004', 'Steve Smith', 'SPD Smith', 'Australian', 'Right-hand bat', 'Right-arm leg break', 'Batsman', 49, 't0000000-0000-0000-0000-000000000002'),
  ('p0000002-0000-0000-0000-000000000005', 'Mitchell Starc', 'MA Starc', 'Australian', 'Left-hand bat', 'Left-arm fast', 'Bowler', 56, 't0000000-0000-0000-0000-000000000002'),
  ('p0000002-0000-0000-0000-000000000006', 'Glenn Maxwell', 'GJ Maxwell', 'Australian', 'Right-hand bat', 'Right-arm off break', 'All-rounder', 32, 't0000000-0000-0000-0000-000000000002'),
  ('p0000002-0000-0000-0000-000000000007', 'Josh Hazlewood', 'JR Hazlewood', 'Australian', 'Right-hand bat', 'Right-arm fast-medium', 'Bowler', 38, 't0000000-0000-0000-0000-000000000002'),
  ('p0000002-0000-0000-0000-000000000008', 'Adam Zampa', 'A Zampa', 'Australian', 'Right-hand bat', 'Right-arm leg break', 'Bowler', 44, 't0000000-0000-0000-0000-000000000002'),
  ('p0000002-0000-0000-0000-000000000009', 'Matthew Wade', 'MS Wade', 'Australian', 'Left-hand bat', 'Right-arm medium', 'Wicket-keeper', 8, 't0000000-0000-0000-0000-000000000002'),
  ('p0000002-0000-0000-0000-000000000010', 'Cameron Green', 'C Green', 'Australian', 'Right-hand bat', 'Right-arm fast-medium', 'All-rounder', 10, 't0000000-0000-0000-0000-000000000002'),
  ('p0000002-0000-0000-0000-000000000011', 'Marcus Stoinis', 'MP Stoinis', 'Australian', 'Right-hand bat', 'Right-arm fast-medium', 'All-rounder', 72, 't0000000-0000-0000-0000-000000000002')
ON CONFLICT DO NOTHING;

-- Demo LIVE match: India vs Australia
INSERT INTO matches (id, series_id, match_number, match_type, overs_per_innings, venue_id, team_a_id, team_b_id, scheduled_at, status, toss_winner_id, toss_decision, batting_first_team_id, current_innings, result_text) VALUES
  ('m0000000-0000-0000-0000-000000000001',
   's0000000-0000-0000-0000-000000000001',
   1, 'T20', 20,
   'v0000000-0000-0000-0000-000000000001',
   't0000000-0000-0000-0000-000000000001',
   't0000000-0000-0000-0000-000000000002',
   NOW() - INTERVAL '2 hours',
   'live',
   't0000000-0000-0000-0000-000000000002',
   'field',
   't0000000-0000-0000-0000-000000000001',
   2,
   NULL)
ON CONFLICT DO NOTHING;

-- Upcoming match
INSERT INTO matches (id, series_id, match_number, match_type, overs_per_innings, venue_id, team_a_id, team_b_id, scheduled_at, status) VALUES
  ('m0000000-0000-0000-0000-000000000002',
   's0000000-0000-0000-0000-000000000001',
   2, 'T20', 20,
   'v0000000-0000-0000-0000-000000000002',
   't0000000-0000-0000-0000-000000000001',
   't0000000-0000-0000-0000-000000000002',
   NOW() + INTERVAL '2 days',
   'upcoming')
ON CONFLICT DO NOTHING;

-- Completed match
INSERT INTO matches (id, series_id, match_number, match_type, overs_per_innings, venue_id, team_a_id, team_b_id, scheduled_at, status, toss_winner_id, toss_decision, batting_first_team_id, result_text, winner_id) VALUES
  ('m0000000-0000-0000-0000-000000000003',
   's0000000-0000-0000-0000-000000000001',
   0, 'T20', 20,
   'v0000000-0000-0000-0000-000000000003',
   't0000000-0000-0000-0000-000000000002',
   't0000000-0000-0000-0000-000000000001',
   NOW() - INTERVAL '3 days',
   'completed',
   't0000000-0000-0000-0000-000000000001',
   'bat',
   't0000000-0000-0000-0000-000000000001',
   'India won by 6 wickets',
   't0000000-0000-0000-0000-000000000001')
ON CONFLICT DO NOTHING;

-- Squads for live match
INSERT INTO squads (match_id, team_id, player_id, is_playing_xi, is_captain, is_wicketkeeper, batting_order) VALUES
  ('m0000000-0000-0000-0000-000000000001', 't0000000-0000-0000-0000-000000000001', 'p0000001-0000-0000-0000-000000000001', true, true, false, 1),
  ('m0000000-0000-0000-0000-000000000001', 't0000000-0000-0000-0000-000000000001', 'p0000001-0000-0000-0000-000000000003', true, false, false, 2),
  ('m0000000-0000-0000-0000-000000000001', 't0000000-0000-0000-0000-000000000001', 'p0000001-0000-0000-0000-000000000002', true, false, false, 3),
  ('m0000000-0000-0000-0000-000000000001', 't0000000-0000-0000-0000-000000000001', 'p0000001-0000-0000-0000-000000000004', true, false, false, 4),
  ('m0000000-0000-0000-0000-000000000001', 't0000000-0000-0000-0000-000000000001', 'p0000001-0000-0000-0000-000000000005', true, false, false, 5),
  ('m0000000-0000-0000-0000-000000000001', 't0000000-0000-0000-0000-000000000001', 'p0000001-0000-0000-0000-000000000007', true, false, true, 6),
  ('m0000000-0000-0000-0000-000000000001', 't0000000-0000-0000-0000-000000000001', 'p0000001-0000-0000-0000-000000000006', true, false, false, 7),
  ('m0000000-0000-0000-0000-000000000001', 't0000000-0000-0000-0000-000000000001', 'p0000001-0000-0000-0000-000000000011', true, false, false, 8),
  ('m0000000-0000-0000-0000-000000000001', 't0000000-0000-0000-0000-000000000001', 'p0000001-0000-0000-0000-000000000008', true, false, false, 9),
  ('m0000000-0000-0000-0000-000000000001', 't0000000-0000-0000-0000-000000000001', 'p0000001-0000-0000-0000-000000000009', true, false, false, 10),
  ('m0000000-0000-0000-0000-000000000001', 't0000000-0000-0000-0000-000000000001', 'p0000001-0000-0000-0000-000000000010', true, false, false, 11)
ON CONFLICT DO NOTHING;

INSERT INTO squads (match_id, team_id, player_id, is_playing_xi, is_captain, is_wicketkeeper, batting_order) VALUES
  ('m0000000-0000-0000-0000-000000000001', 't0000000-0000-0000-0000-000000000002', 'p0000002-0000-0000-0000-000000000002', true, false, false, 1),
  ('m0000000-0000-0000-0000-000000000001', 't0000000-0000-0000-0000-000000000002', 'p0000002-0000-0000-0000-000000000003', true, false, false, 2),
  ('m0000000-0000-0000-0000-000000000001', 't0000000-0000-0000-0000-000000000002', 'p0000002-0000-0000-0000-000000000004', true, false, false, 3),
  ('m0000000-0000-0000-0000-000000000001', 't0000000-0000-0000-0000-000000000002', 'p0000002-0000-0000-0000-000000000006', true, false, false, 4),
  ('m0000000-0000-0000-0000-000000000001', 't0000000-0000-0000-0000-000000000002', 'p0000002-0000-0000-0000-000000000010', true, false, false, 5),
  ('m0000000-0000-0000-0000-000000000001', 't0000000-0000-0000-0000-000000000002', 'p0000002-0000-0000-0000-000000000011', true, false, false, 6),
  ('m0000000-0000-0000-0000-000000000001', 't0000000-0000-0000-0000-000000000002', 'p0000002-0000-0000-0000-000000000009', true, false, true, 7),
  ('m0000000-0000-0000-0000-000000000001', 't0000000-0000-0000-0000-000000000002', 'p0000002-0000-0000-0000-000000000001', true, true, false, 8),
  ('m0000000-0000-0000-0000-000000000001', 't0000000-0000-0000-0000-000000000002', 'p0000002-0000-0000-0000-000000000005', true, false, false, 9),
  ('m0000000-0000-0000-0000-000000000001', 't0000000-0000-0000-0000-000000000002', 'p0000002-0000-0000-0000-000000000007', true, false, false, 10),
  ('m0000000-0000-0000-0000-000000000001', 't0000000-0000-0000-0000-000000000002', 'p0000002-0000-0000-0000-000000000008', true, false, false, 11)
ON CONFLICT DO NOTHING;

-- Innings 1: India batting (completed - 186/5 in 20 overs)
INSERT INTO innings (id, match_id, innings_number, batting_team_id, bowling_team_id, total_runs, total_wickets, total_overs, total_balls, extras_total, extras_wides, extras_no_balls, extras_byes, extras_leg_byes, current_run_rate, status, all_out, powerplay_score, powerplay_wickets) VALUES
  ('i0000001-0000-0000-0000-000000000001',
   'm0000000-0000-0000-0000-000000000001',
   1,
   't0000000-0000-0000-0000-000000000001',
   't0000000-0000-0000-0000-000000000002',
   186, 5, 20.0, 120, 9, 5, 2, 1, 1,
   9.30, 'completed', false, 52, 1)
ON CONFLICT DO NOTHING;

-- Innings 2: Australia chasing 187 (live - 89/3 in 10.2 overs)
INSERT INTO innings (id, match_id, innings_number, batting_team_id, bowling_team_id, target, total_runs, total_wickets, total_overs, total_balls, extras_total, extras_wides, extras_no_balls, extras_byes, extras_leg_byes, current_run_rate, required_run_rate, status, powerplay_score, powerplay_wickets, current_striker_id, current_non_striker_id, current_bowler_id) VALUES
  ('i0000001-0000-0000-0000-000000000002',
   'm0000000-0000-0000-0000-000000000001',
   2,
   't0000000-0000-0000-0000-000000000002',
   't0000000-0000-0000-0000-000000000001',
   187, 89, 3, 10.2, 62, 4, 2, 1, 0, 1,
   8.64, 10.32, 'in_progress', 58, 1,
   'p0000002-0000-0000-0000-000000000006',
   'p0000002-0000-0000-0000-000000000004',
   'p0000001-0000-0000-0000-000000000006')
ON CONFLICT DO NOTHING;

-- Batter stats - Innings 1 (India)
INSERT INTO batter_stats (innings_id, player_id, team_id, batting_order, runs, balls_faced, fours, sixes, strike_rate, dismissal_type, status) VALUES
  ('i0000001-0000-0000-0000-000000000001', 'p0000001-0000-0000-0000-000000000001', 't0000000-0000-0000-0000-000000000001', 1, 67, 42, 5, 4, 159.52, 'caught', 'out'),
  ('i0000001-0000-0000-0000-000000000001', 'p0000001-0000-0000-0000-000000000003', 't0000000-0000-0000-0000-000000000001', 2, 14, 12, 2, 0, 116.67, 'bowled', 'out'),
  ('i0000001-0000-0000-0000-000000000001', 'p0000001-0000-0000-0000-000000000002', 't0000000-0000-0000-0000-000000000001', 3, 52, 38, 4, 2, 136.84, 'lbw', 'out'),
  ('i0000001-0000-0000-0000-000000000001', 'p0000001-0000-0000-0000-000000000004', 't0000000-0000-0000-0000-000000000001', 4, 34, 20, 2, 2, 170.00, 'caught', 'out'),
  ('i0000001-0000-0000-0000-000000000001', 'p0000001-0000-0000-0000-000000000005', 't0000000-0000-0000-0000-000000000001', 5, 12, 9, 1, 0, 133.33, 'run_out', 'out'),
  ('i0000001-0000-0000-0000-000000000001', 'p0000001-0000-0000-0000-000000000007', 't0000000-0000-0000-0000-000000000001', 6, 5, 4, 0, 0, 125.00, NULL, 'not_out'),
  ('i0000001-0000-0000-0000-000000000001', 'p0000001-0000-0000-0000-000000000006', 't0000000-0000-0000-0000-000000000001', 7, 0, 0, 0, 0, 0, NULL, 'dnb'),
  ('i0000001-0000-0000-0000-000000000001', 'p0000001-0000-0000-0000-000000000011', 't0000000-0000-0000-0000-000000000001', 8, 0, 0, 0, 0, 0, NULL, 'dnb'),
  ('i0000001-0000-0000-0000-000000000001', 'p0000001-0000-0000-0000-000000000008', 't0000000-0000-0000-0000-000000000001', 9, 0, 0, 0, 0, 0, NULL, 'dnb'),
  ('i0000001-0000-0000-0000-000000000001', 'p0000001-0000-0000-0000-000000000009', 't0000000-0000-0000-0000-000000000001', 10, 0, 0, 0, 0, 0, NULL, 'dnb'),
  ('i0000001-0000-0000-0000-000000000001', 'p0000001-0000-0000-0000-000000000010', 't0000000-0000-0000-0000-000000000001', 11, 0, 0, 0, 0, 0, NULL, 'dnb')
ON CONFLICT DO NOTHING;

-- Bowler stats - Innings 1 (Australia bowling)
INSERT INTO bowler_stats (innings_id, player_id, team_id, overs_bowled, balls_bowled, maidens, runs_conceded, wickets, economy, wides, no_balls) VALUES
  ('i0000001-0000-0000-0000-000000000001', 'p0000002-0000-0000-0000-000000000005', 't0000000-0000-0000-0000-000000000002', 4.0, 24, 0, 38, 2, 9.50, 2, 0),
  ('i0000001-0000-0000-0000-000000000001', 'p0000002-0000-0000-0000-000000000007', 't0000000-0000-0000-0000-000000000002', 4.0, 24, 0, 32, 1, 8.00, 1, 1),
  ('i0000001-0000-0000-0000-000000000001', 'p0000002-0000-0000-0000-000000000008', 't0000000-0000-0000-0000-000000000002', 4.0, 24, 0, 28, 1, 7.00, 0, 1),
  ('i0000001-0000-0000-0000-000000000001', 'p0000002-0000-0000-0000-000000000001', 't0000000-0000-0000-0000-000000000002', 4.0, 24, 0, 44, 1, 11.00, 2, 0),
  ('i0000001-0000-0000-0000-000000000001', 'p0000002-0000-0000-0000-000000000006', 't0000000-0000-0000-0000-000000000002', 3.0, 18, 0, 29, 0, 9.67, 0, 0),
  ('i0000001-0000-0000-0000-000000000001', 'p0000002-0000-0000-0000-000000000011', 't0000000-0000-0000-0000-000000000002', 1.0, 6, 0, 15, 0, 15.00, 0, 0)
ON CONFLICT DO NOTHING;

-- Batter stats - Innings 2 (Australia, in progress)
INSERT INTO batter_stats (innings_id, player_id, team_id, batting_order, runs, balls_faced, fours, sixes, strike_rate, dismissal_type, status) VALUES
  ('i0000001-0000-0000-0000-000000000002', 'p0000002-0000-0000-0000-000000000002', 't0000000-0000-0000-0000-000000000002', 1, 22, 18, 3, 0, 122.22, 'caught', 'out'),
  ('i0000001-0000-0000-0000-000000000002', 'p0000002-0000-0000-0000-000000000003', 't0000000-0000-0000-0000-000000000002', 2, 31, 22, 3, 1, 140.91, 'bowled', 'out'),
  ('i0000001-0000-0000-0000-000000000002', 'p0000002-0000-0000-0000-000000000004', 't0000000-0000-0000-0000-000000000002', 3, 18, 19, 1, 0, 94.74, NULL, 'batting'),
  ('i0000001-0000-0000-0000-000000000002', 'p0000002-0000-0000-0000-000000000006', 't0000000-0000-0000-0000-000000000002', 4, 14, 9, 0, 1, 155.56, NULL, 'batting'),
  ('i0000001-0000-0000-0000-000000000002', 'p0000002-0000-0000-0000-000000000010', 't0000000-0000-0000-0000-000000000002', 5, 4, 3, 0, 0, 133.33, 'lbw', 'out'),
  ('i0000001-0000-0000-0000-000000000002', 'p0000002-0000-0000-0000-000000000011', 't0000000-0000-0000-0000-000000000002', 6, 0, 0, 0, 0, 0, NULL, 'yet_to_bat'),
  ('i0000001-0000-0000-0000-000000000002', 'p0000002-0000-0000-0000-000000000009', 't0000000-0000-0000-0000-000000000002', 7, 0, 0, 0, 0, 0, NULL, 'yet_to_bat'),
  ('i0000001-0000-0000-0000-000000000002', 'p0000002-0000-0000-0000-000000000001', 't0000000-0000-0000-0000-000000000002', 8, 0, 0, 0, 0, 0, NULL, 'yet_to_bat'),
  ('i0000001-0000-0000-0000-000000000002', 'p0000002-0000-0000-0000-000000000005', 't0000000-0000-0000-0000-000000000002', 9, 0, 0, 0, 0, 0, NULL, 'yet_to_bat'),
  ('i0000001-0000-0000-0000-000000000002', 'p0000002-0000-0000-0000-000000000007', 't0000000-0000-0000-0000-000000000002', 10, 0, 0, 0, 0, 0, NULL, 'yet_to_bat'),
  ('i0000001-0000-0000-0000-000000000002', 'p0000002-0000-0000-0000-000000000008', 't0000000-0000-0000-0000-000000000002', 11, 0, 0, 0, 0, 0, NULL, 'yet_to_bat')
ON CONFLICT DO NOTHING;

-- Bowler stats - Innings 2 (India bowling, in progress)
INSERT INTO bowler_stats (innings_id, player_id, team_id, overs_bowled, balls_bowled, maidens, runs_conceded, wickets, economy, wides, no_balls) VALUES
  ('i0000001-0000-0000-0000-000000000002', 'p0000001-0000-0000-0000-000000000008', 't0000000-0000-0000-0000-000000000001', 3.0, 18, 0, 22, 1, 7.33, 1, 0),
  ('i0000001-0000-0000-0000-000000000002', 'p0000001-0000-0000-0000-000000000010', 't0000000-0000-0000-0000-000000000001', 3.0, 18, 0, 28, 1, 9.33, 1, 1),
  ('i0000001-0000-0000-0000-000000000002', 'p0000001-0000-0000-0000-000000000006', 't0000000-0000-0000-0000-000000000001', 2.2, 14, 0, 18, 1, 7.71, 0, 0),
  ('i0000001-0000-0000-0000-000000000002', 'p0000001-0000-0000-0000-000000000009', 't0000000-0000-0000-0000-000000000001', 2.0, 12, 0, 21, 0, 10.50, 0, 0)
ON CONFLICT DO NOTHING;

-- Fall of wickets - Innings 2
INSERT INTO fall_of_wickets (innings_id, wicket_number, player_id, score, overs, dismissal_type) VALUES
  ('i0000001-0000-0000-0000-000000000002', 1, 'p0000002-0000-0000-0000-000000000002', 42, 5.3, 'caught'),
  ('i0000001-0000-0000-0000-000000000002', 2, 'p0000002-0000-0000-0000-000000000003', 71, 8.1, 'bowled'),
  ('i0000001-0000-0000-0000-000000000002', 3, 'p0000002-0000-0000-0000-000000000010', 85, 9.4, 'lbw')
ON CONFLICT DO NOTHING;

-- Sample commentary - Innings 2
INSERT INTO commentary (match_id, innings_id, over_number, ball_number, commentary_type, text) VALUES
  ('m0000000-0000-0000-0000-000000000001', 'i0000001-0000-0000-0000-000000000002', 10, 2, 'regular', '10.2: Jadeja to Maxwell, SIX! What a shot! Maxwell dances down the track and lofts it over long-on with absolute authority. Maxwell 14(9)'),
  ('m0000000-0000-0000-0000-000000000001', 'i0000001-0000-0000-0000-000000000002', 10, 1, 'regular', '10.1: Jadeja to Maxwell, 1 run. Pushed into the off-side gap, easy single taken to deep cover.'),
  ('m0000000-0000-0000-0000-000000000001', 'i0000001-0000-0000-0000-000000000002', 9, 6, 'wicket', '9.6: Arshdeep to Green, OUT! LBW! Arshdeep nips one back off the seam and traps Green plumb in front. Green goes for 4(3). India strike!'),
  ('m0000000-0000-0000-0000-000000000001', 'i0000001-0000-0000-0000-000000000002', 9, 5, 'regular', '9.5: Arshdeep to Green, dot. Good length delivery on off stump, Green defends solidly back to the bowler.'),
  ('m0000000-0000-0000-0000-000000000001', 'i0000001-0000-0000-0000-000000000002', 8, 1, 'wicket', '8.1: Arshdeep to Head, OUT! BOWLED! What a delivery! Swings in late and takes out the off stump. Head walks back for 31(22). Big wicket for India!'),
  ('m0000000-0000-0000-0000-000000000001', 'i0000001-0000-0000-0000-000000000002', 5, 3, 'wicket', '5.3: Bumrah to Warner, OUT! Caught behind! Warner drives at one outside off, gets a thick outside edge and Wade takes a comfortable catch. Warner departs for 22(18).')
ON CONFLICT DO NOTHING;
