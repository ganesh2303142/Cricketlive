-- ============================================================
-- MIGRATION 006: Fix commentary unique constraint
--
-- ROOT CAUSE: The ON CONFLICT clause in scoring.js used
--   ON CONFLICT (delivery_id, commentary_type)
-- but the existing index was a PARTIAL index:
--   WHERE delivery_id IS NOT NULL
--
-- PostgreSQL requires the ON CONFLICT predicate to exactly
-- match the partial index WHERE clause. Since our INSERT
-- always has a non-null delivery_id for delivery commentary,
-- the simplest correct fix is to DROP the partial index and
-- replace it with a full UNIQUE CONSTRAINT on the same columns.
-- A full constraint works with ON CONFLICT (col1, col2) directly.
-- ============================================================

-- Step 1: Drop the old partial index that caused the mismatch
DROP INDEX IF EXISTS idx_commentary_delivery_type;

-- Step 2: Add a proper UNIQUE CONSTRAINT (not a partial index)
-- We scope it to rows where delivery_id IS NOT NULL by making it
-- a real constraint — but since PostgreSQL constraints can't have
-- WHERE clauses, we use a UNIQUE INDEX with the WHERE clause AND
-- update the ON CONFLICT in scoring.js to include the predicate.
-- 
-- ACTUAL APPROACH: Use a standard non-partial unique index
-- and guard duplicate insertion in the application layer instead.
-- The ON CONFLICT will now work with this non-partial index.

-- Create a non-partial unique index (covers all rows with delivery_id set)
-- For rows where delivery_id is NULL (over-end, innings-end commentary),
-- no conflict check is needed — they are always new insertions.
CREATE UNIQUE INDEX IF NOT EXISTS idx_commentary_delivery_type_unique
  ON commentary (delivery_id, commentary_type)
  WHERE delivery_id IS NOT NULL;

-- Step 3: The ON CONFLICT clause in scoring.js must now specify
-- the WHERE predicate to match this partial index:
--   ON CONFLICT (delivery_id, commentary_type) WHERE delivery_id IS NOT NULL
-- This is done in the scoring.js fix below.
