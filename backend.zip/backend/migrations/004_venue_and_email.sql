-- ============================================================
-- MIGRATION 004: venue_name column, max innings guard
-- ============================================================

-- Add venue_name directly to matches (no need for venues table lookup for simple text)
ALTER TABLE matches ADD COLUMN IF NOT EXISTS venue_name VARCHAR(255);

-- Ensure innings_number is still constrained to 1-4 (existing CHECK)
-- Add a trigger to prevent more than 2 innings per match in normal formats
-- (Test cricket can have 4, but our app only does 2)
-- We enforce this at the application level; the DB still allows up to 4 per schema.

-- Update the admin email from demo to real email
UPDATE users
SET email = 'ganeshsanjan78@gmail.com'
WHERE email = 'admin@cricket.live'
  AND deleted_at IS NULL;

-- Update seed scorer email to something safe
UPDATE users
SET email = 'scorer@ganeshcricket.local'
WHERE email = 'scorer@cricket.live'
  AND deleted_at IS NULL;

-- Index for venue_name
CREATE INDEX IF NOT EXISTS idx_matches_venue_name ON matches(venue_name);
