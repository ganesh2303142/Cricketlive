-- ============================================================
-- MIGRATION 005: Vice Captain + Man of the Match
-- ============================================================

-- Add is_vice_captain to squads table
ALTER TABLE squads ADD COLUMN IF NOT EXISTS is_vice_captain BOOLEAN DEFAULT false;

-- man_of_match_id already exists on matches table from 001_initial_schema.sql
-- man_of_match_id UUID REFERENCES players(id)
-- But we need to confirm and add man_of_match_name for display fallback
-- Also add motm_team_id to know which team the MOTM belonged to
ALTER TABLE matches ADD COLUMN IF NOT EXISTS man_of_match_team_id UUID REFERENCES teams(id);

-- Index
CREATE INDEX IF NOT EXISTS idx_squads_vice_captain ON squads(match_id, is_vice_captain);
CREATE INDEX IF NOT EXISTS idx_matches_motm ON matches(man_of_match_id);

-- ── Commentary deduplication ───────────────────────────────────────────────
-- Add a unique index so that one delivery can only have ONE 'regular' commentary row.
-- Milestone, admin, innings_end rows are linked by delivery_id but different type,
-- so we scope uniqueness to (delivery_id, commentary_type) for delivery-linked rows.
CREATE UNIQUE INDEX IF NOT EXISTS idx_commentary_delivery_type
  ON commentary (delivery_id, commentary_type)
  WHERE delivery_id IS NOT NULL;
